<?php
/**
 * หน้าข้อมูลชมรมหลัก (UDRU E-sports Portal - index.php)
 * ทำหน้าที่แสดงข้อมูลชมรม สถิติความสำเร็จ และให้ลิงก์เพื่อเข้าสู่ระบบหรือลงทะเบียนสมัครคัดตัวใหม่
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UDRU E-sports Club Portal</title>
    <!-- โหลด Tailwind CSS ผ่านระบบ CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- โหลดแบบอักษร Mitr (TH) และ Space Grotesk (EN) -->
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Mitr', 'Space Grotesk', sans-serif;
        }
    </style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex flex-col justify-between relative overflow-x-hidden">
    
    <!-- พื้นหลังแอนิเมชัน Gradients และตาข่ายเส้นตาราง -->
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.12)_0%,rgba(0,0,0,1)_85%)] pointer-events-none -z-20"></div>
    <div class="absolute inset-0 opacity-15 pointer-events-none -z-10" style="background-image: linear-gradient(#334155 1px, transparent 1px), linear-gradient(90deg, #334155 1px, transparent 1px); background-size: 40px 40px;"></div>

    <!-- HEADER -->
    <header class="w-full h-20 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md flex items-center justify-between px-6 md:px-12">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span class="transform -rotate-45 font-black text-slate-950 text-xl font-mono">U</span>
            </div>
            <div>
                <h1 class="text-lg md:text-xl font-bold tracking-tighter uppercase italic text-cyan-400">UDRU E-SPORTS</h1>
                <p class="text-[9px] tracking-[0.2em] text-slate-400 uppercase font-mono">Official Club Portal</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-[9px] text-slate-500 uppercase font-mono">SYSTEM_STATUS</span>
            <span class="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]"></span>
        </div>
    </header>

    <!-- MAIN PORTAL CONTENT -->
    <main class="max-w-4xl mx-auto py-16 px-6 space-y-12 relative z-10 flex-grow">
        
        <!-- Welcome Hero Section -->
        <div class="text-center space-y-4">
            <span class="px-3 py-1 bg-cyan-950/60 text-cyan-400 border border-cyan-800 text-xs font-mono rounded-full tracking-wider uppercase">// WELCOME TO THE ARENA</span>
            <h2 class="text-3xl md:text-5xl font-black italic text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-cyan-400 uppercase tracking-tight">ชมรมอีสปอร์ต มหาวิทยาลัยราชภัฏอุดรธานี</h2>
            <p class="text-slate-400 max-w-2xl mx-auto text-sm leading-relaxed">
                แหล่งรวบรวมทักษะ พัฒนาฝีมือ และยกระดับนักศึกษาสู่ระดับการแข่งขันมืออาชีพ <br>
                ก้าวเข้ามาเพื่อเป็นส่วนหนึ่งของทีมคัดตัวตัวจริง มาร่วมทดสอบปฏิกิริยาการตอบสนองความไวด้วยระบบ AI ตรวจจับฝ่ามือ!
            </p>
        </div>

        <!-- Statistics Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-black/40 border border-slate-900 p-6 rounded-xl text-center backdrop-blur-sm">
                <div class="text-2xl font-black text-cyan-400 mb-1">3+ เหรียญทอง</div>
                <div class="text-xs text-slate-400">กีฬามหาวิทยาลัยราชภัฏแห่งประเทศไทย</div>
            </div>
            <div class="bg-black/40 border border-slate-900 p-6 rounded-xl text-center backdrop-blur-sm">
                <div class="text-2xl font-black text-emerald-400 mb-1">150+ สมาชิก</div>
                <div class="text-xs text-slate-400">จากทุกคณะร่วมสร้างสรรค์คอมมูนิตี้</div>
            </div>
            <div class="bg-black/40 border border-slate-900 p-6 rounded-xl text-center backdrop-blur-sm">
                <div class="text-2xl font-black text-amber-500 mb-1">AI Hand Tracker</div>
                <div class="text-xs text-slate-400">ระบบคัดเลือกนวัตกรรมตรวจจับด้วยกล้อง</div>
            </div>
        </div>

        <!-- Recruitment CTA Area -->
        <div class="bg-black/60 border-2 border-cyan-500/20 p-8 rounded-xl text-center relative overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.1)]">
            <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-500 rounded-tl"></div>
            <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-500 rounded-tr"></div>
            <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-500 rounded-bl"></div>
            <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-500 rounded-br"></div>
            
            <h3 class="text-xl md:text-2xl font-bold uppercase text-white tracking-tight italic mb-3">ระบบสมัครและทดสอบคัดเลือกนักกีฬา</h3>
            <p class="text-xs text-slate-400 max-w-lg mx-auto mb-6 leading-relaxed">
                หากต้องการเข้าร่วมการทดสอบประสาทสัมผัส (Reflex Challenge) เพื่อบันทึกสถิติลงตารางผู้ท้าชิงของชมรม กรุณาเข้าสู่ระบบด้วยรหัสนักศึกษา หรือลงทะเบียนสมัครคัดตัวรายใหม่
            </p>

            <div class="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <a href="login.php" class="flex-1 py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs uppercase italic tracking-widest rounded transition-all transform hover:scale-[1.02] text-center flex items-center justify-center">
                    เข้าสู่ระบบด้วยรหัสเดิม (LOGIN)
                </a>
                <a href="register.php" class="flex-1 py-3.5 border border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 font-black text-xs uppercase italic tracking-widest rounded transition-all text-center flex items-center justify-center">
                    สมัครคัดตัวใหม่ (REGISTER)
                </a>
            </div>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="w-full h-12 bg-slate-900/40 border-t border-slate-900 flex items-center justify-center text-[10px] text-slate-500 tracking-[0.2em] uppercase text-center font-mono">
        © 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี
    </footer>
</body>
</html>
