<?php
/**
 * ไฟล์ PHP สำหรับอัปเดตคะแนนผ่าน AJAX/Fetch API
 * รับข้อมูลแบบ JSON POST เข้ามาตรวจสอบเซสชัน และเซฟคะแนนผู้สมัครลงฐานข้อมูล
 */

// 1. เริ่มเซสชันเพื่อดึง ID ตัวตนผู้สมัครที่ลงชื่อไว้ในหน้า index.php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 2. ตั้งค่าการส่งข้อมูลกลับเป็น JSON
header('Content-Type: application/json; charset=utf-8');

// 3. นำเข้าไฟล์เชื่อมต่อฐานข้อมูล PDO
require_once 'db.php';

// 4. ตรวจสอบว่าส่งคำขอเข้าแบบ POST หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // ดึงข้อมูลดิบจากส่วนเนื้อหาคำขอ (Request Body) ที่ส่งมาเป็น JSON
    $json_raw = file_get_contents('php://input');
    $data = json_decode($json_raw, true);
    
    // ตรวจสอบความถูกต้องของคะแนนที่ได้ และสถานะความเชื่อมโยงในเซสชัน
    if (isset($data['score']) && isset($_SESSION['applicant_id'])) {
        $score = intval($data['score']);
        $applicant_id = intval($_SESSION['applicant_id']);
        
        try {
            // ดึงคะแนนเดิมขึ้นมาเปรียบเทียบ (เพื่อให้บันทึกคะแนนสูงสุดที่ดีที่สุด หรือจะเขียนทับไปเลย)
            $check_sql = "SELECT game_score FROM rov_applicants WHERE id = :id";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([':id' => $applicant_id]);
            $applicant = $check_stmt->fetch();
            
            if ($applicant) {
                // หากคะแนนใหม่สูงกว่าคะแนนเดิม ให้ทำบันทึกทับเพื่อป้องกันผู้คัดสมัครโกงคะแนนย้อนหลัง
                $best_score = max($score, intval($applicant['game_score']));
                
                $update_sql = "UPDATE rov_applicants SET game_score = :score WHERE id = :id";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->execute([
                    ':score' => $best_score,
                    ':id' => $applicant_id
                ]);
                
                // ตอบกลับความสำเร็จเป็นรูปแบบ JSON ให้ฝั่ง JavaScript นำไปประมวลผลต่อ
                echo json_encode([
                    'success' => true,
                    'message' => 'บันทึกคะแนนสะสมความไวลงสู่ฐานข้อมูล UDRU สำเร็จ!',
                    'score' => $best_score
                ]);
                exit();
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'ไม่พบข้อมูลรหัสผู้ลงสมัครในฐานข้อมูล!'
                ]);
                exit();
            }
        } catch (PDOException $e) {
            echo json_encode([
                'success' => false,
                'message' => 'ฐานข้อมูลผิดพลาด: ' . $e->getMessage()
            ]);
            exit();
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'พารามิเตอร์ผิดพลาด! ไม่พบคะแนนที่ส่งเข้ามา หรือเซสชันหมดอายุ กรุณาลงทะเบียนใหม่อีกครั้ง'
        ]);
        exit();
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'รองรับเฉพาะคำขอแบบ POST เท่านั้น!'
    ]);
    exit();
}
?>
