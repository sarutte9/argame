<?php
/**
 * ไฟล์เชื่อมต่อฐานข้อมูล MySQL (UDRU E-sports Registration)
 * ใช้งานเทคโนโลยี PDO (PHP Data Objects) ซึ่งมีความปลอดภัยและป้องกัน SQL Injection ได้ดีที่สุด
 */

$host = "localhost";        // ที่อยู่ของฐานข้อมูล (สำหรับ XAMPP บนเครื่องตนเองคือ localhost)
$db_name = "udru_esports";  // ชื่อฐานข้อมูลที่ตั้งค่าใน database.sql
$username = "root";         // ชื่อผู้ใช้งานดีฟอลต์ของ XAMPP
$password = "";             // รหัสผ่านเข้าฐานข้อมูล (ดีฟอลต์ของ XAMPP บน Windows จะเว้นว่างไว้)

try {
    // 1. เริ่มต้นเชื่อมต่อฐานข้อมูลโดยระบุที่อยู่, ชื่อ db และเลือกใช้ภาษา utf8mb4 สำหรับรองรับภาษาไทย
    $conn = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    
    // 2. ตั้งค่าให้แสดง Exception เมื่อเกิดข้อผิดพลาดในการรัน SQL ป้องกันการปิดบัง error ที่ตรวจพบยาก
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 3. ตั้งค่า Fetch mode ดีฟอลต์ให้คืนค่าเป็นอะเรย์เชื่อมโยงแบบคีย์เป็นชื่อฟิลด์ (Associative Array)
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // 4. บังคับปิดจำลอง Prepare Statements เพื่อความปลอดภัยระดับสูงสุดจาก SQL Injection
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $e) {
    // ดักจับและยกเลิกกระบวนการทำงานทันทีหากเชื่อมต่อล้มเหลว พร้อมแสดงข้อความเตือนความผิดพลาด
    die("เชื่อมต่อฐานข้อมูลล้มเหลวกรุณาตรวจสอบว่าเปิด MySQL ใน XAMPP Control Panel แล้วหรือยัง? <br><b>ข้อความความผิดพลาด:</b> " . $e->getMessage());
}
?>
