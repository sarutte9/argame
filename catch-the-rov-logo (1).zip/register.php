<?php
/**
 * หน้าสมัครสมาชิกผู้สมัครรายใหม่ (register.php)
 * บันทึกประวัติเบื้องต้น ท่าทาง ตำแหน่งที่ถนัด เข้าตาราง MySQL และส่งต่อไปยังหน้าเกมทดสอบ
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
    $fullname = isset($_POST['fullname']) ? trim($_POST['fullname']) : '';
    $in_game_name = isset($_POST['in_game_name']) ? trim($_POST['in_game_name']) : '';
    $primary_role = isset($_POST['primary_role']) ? trim($_POST['primary_role']) : '';

    if (empty($student_id) || empty($fullname) || empty($in_game_name) || empty($primary_role)) {
        $error_msg = "กรุณากรอกข้อมูลให้ครบถ้วนทุกช่อง!";
    } else {
        try {
            // ตรวจสอบในฐานข้อมูลว่า รหัสนักศึกษาคนนี้เคยลงทะเบียนสมัครหรือยัง
            $check_sql = "SELECT id, fullname FROM rov_applicants WHERE student_id = :student_id LIMIT 1";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([':student_id' => $student_id]);
            
            if ($check_stmt->rowCount() > 0) {
                // หากพบข้อมูลเดิม: ให้ส่งไปที่เข้าสู่ระบบหรือดึงค่ามาใช้งานทันที
                $existing_user = $check_stmt->fetch();
                $_SESSION['applicant_id'] = $existing_user['id'];
                $_SESSION['student_id'] = $student_id;
                $_SESSION['fullname'] = $existing_user['fullname'];
                
                header("Location: game.html");
                exit();
            } else {
                // หากเป็นคนใหม่: บันทึกรายการสมัครลงตาราง rov_applicants คืนค่า id ล่าสุด
                $insert_sql = "INSERT INTO rov_applicants (student_id, fullname, in_game_name, primary_role, game_score) 
                               VALUES (:student_id, :fullname, :in_game_name, :primary_role, 0)";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->execute([
                    ':student_id' => $student_id,
                    ':fullname' => $fullname,
                    ':in_game_name' => $in_game_name,
                    ':primary_role' => $primary_role
                ]);
                
                $_SESSION['applicant_id'] = $conn->lastInsertId();
                $_SESSION['student_id'] = $student_id;
                $_SESSION['fullname'] = $fullname;
                
                header("Location: game.html");
                exit();
            }
        } catch (PDOException $e) {
            $error_msg = "ฐานข้อมูลเชื่อมต่อผิดพลาด: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ลงทะเบียนคัดตัว UDRU E-sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Mitr', 'Space Grotesk', sans-serif; }</style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex flex-col justify-between relative overflow-x-hidden">
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.12)_0%,rgba(0,0,0,1)_85%)] pointer-events-none -z-20"></div>
    
    <!-- HEADER -->
    <header class="w-full h-20 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md flex items-center justify-between px-6">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span class="transform -rotate-45 font-black text-slate-950 text-xl font-mono">U</span>
            </div>
            <h1 class="text-lg md:text-xl font-bold tracking-tighter uppercase italic text-cyan-400">UDRU E-SPORTS</h1>
        </div>
        <a href="index.php" class="text-xs text-slate-400 hover:text-cyan-400 transition-colors font-mono">← BACK PORTAL</a>
    </header>

    <!-- REGISTER FORM -->
    <main class="flex-grow flex items-center justify-center py-12 px-4 relative z-10">
        <div class="w-full max-w-md bg-black/60 border-2 border-cyan-500/30 p-8 rounded-xl relative shadow-[0_0_50px_rgba(6,182,212,0.15)]">
            
            <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-500 rounded-tl"></div>
            <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-500 rounded-tr"></div>
            <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-500 rounded-bl"></div>
            <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-500 rounded-br"></div>

            <h2 class="text-2xl font-black italic text-center uppercase text-white mb-2">สมัครคัดเลือกใหม่</h2>
            <p class="text-center text-xs text-slate-400 mb-6">กรอกประวัติเบื้องต้นเพื่อเชื่อมโยงกับฐานข้อมูลของชมรม</p>

            <?php if (!empty($error_msg)): ?>
                <div class="mb-5 p-3 rounded bg-red-950/40 border border-red-500/30 text-red-300 text-xs text-center">
                    ⚠️ <?php echo htmlspecialchars($error_msg); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-4">
                <!-- รหัสนักศึกษา -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">รหัสนักศึกษา (Student ID)</label>
                    <input 
                        type="text" 
                        name="student_id" 
                        required 
                        pattern="[0-9\-]+"
                        placeholder="66XXXXXXXX-X" 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200 font-mono"
                    >
                </div>

                <!-- ชื่อจริง -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">ชื่อ - นามสกุลจริง (Fullname)</label>
                    <input 
                        type="text" 
                        name="fullname" 
                        required 
                        placeholder="สมชาย เก่งกล้า" 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200"
                    >
                </div>

                <!-- ชื่อในเกม -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">ชื่อเรียกในเกม (In-Game Name)</label>
                    <input 
                        type="text" 
                        name="in_game_name" 
                        required 
                        placeholder="UDRU_CarryGod" 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200"
                    >
                </div>

                <!-- ตำแหน่งถนัด -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">ตำแหน่งที่ถนัด (Primary Role)</label>
                    <select 
                        name="primary_role" 
                        required 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200 cursor-pointer"
                    >
                        <option value="">-- เลือกหน้าที่หลัก --</option>
                        <option value="Abyssal Dragon Lane (Carry)">Abyssal Dragon Lane (Carry) - แครี่ดาเมจ</option>
                        <option value="Dark Slayer Lane (Fighter)">Dark Slayer Lane (Fighter) - ออฟเลนถึกทน</option>
                        <option value="Middle Lane (Mage)">Middle Lane (Mage) - เมจเวทควบคุม</option>
                        <option value="Jungle (Assassin)">Jungle (Assassin) - ป่าโจมตีฉับไว</option>
                        <option value="Roaming (Support/Tank)">Roaming (Support/Tank) - ซัพพอร์ตปกป้องเพื่อน</option>
                    </select>
                </div>

                <button type="submit" class="w-full py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic text-xs tracking-widest rounded transform -skew-x-12 transition-all shadow-[0_5px_15px_rgba(6,182,212,0.3)] pt-3">
                    บันทึกข้อมูลสมัคร &amp; เริ่มสอบ 🚀
                </button>
            </form>

            <div class="mt-6 text-center text-xs text-slate-400 font-sans">
                มีประวัติสมัครอยู่แล้ว? <a href="login.php" class="text-cyan-400 hover:underline">เข้าสู่ระบบที่นี่</a>
            </div>
        </div>
    </main>

    <footer class="w-full h-12 bg-slate-900/40 border-t border-slate-900 flex items-center justify-center text-[10px] text-slate-500 tracking-[0.2em] uppercase text-center font-mono">
        © 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี
    </footer>
</body>
</html>
