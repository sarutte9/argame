// ซอร์สโค้ดไฟล์ทั้งหมดสำหรับระบบสมัครและทดสอบนักกีฬา UDRU E-sports เพื่อเปิดดูและดาวน์โหลด

export interface SourceFile {
  name: string;
  language: string;
  description: string;
  content: string;
}

export const sourceFiles: SourceFile[] = [
  {
    name: "database.sql",
    language: "sql",
    description: "คำสั่งสร้างฐานข้อมูล MySQL และสร้างตาราง `rov_applicants` เพื่อเก็บรายชื่อและคะแนนสอบ",
    content: `-- =========================================================
-- สคริปต์สร้างฐานข้อมูล MySQL สำหรับระบบรับสมัครนักกีฬา UDRU E-sports
-- คำแนะนำ: นำโค้ดทั้งหมดนี้ไปรันในแท็บ SQL ของ phpMyAdmin ใน XAMPP
-- =========================================================

-- 1. สร้างฐานข้อมูลใหม่ (หากยังไม่มีอยู่)
CREATE DATABASE IF NOT EXISTS \`udru_esports\` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- 2. เลือกใช้งานฐานข้อมูลนี้
USE \`udru_esports\`;

-- 3. สร้างตารางเก็บข้อมูลผู้ลงสมัครนักกีฬาและสถิติคะแนนเกมทดสอบปฏิกิริยาตอบสนอง
CREATE TABLE IF NOT EXISTS \`rov_applicants\` (
    \`id\` INT AUTO_INCREMENT PRIMARY KEY,                -- ลำดับที่ (Primary Key, เพิ่มขึ้นอัตโนมัติ)
    \`student_id\` VARCHAR(20) NOT NULL UNIQUE,          -- รหัสนักศึกษา (ห้ามซ้ำซ้อน)
    \`fullname\` VARCHAR(100) NOT NULL,                  -- ชื่อ-นามสกุลจริง
    \`in_game_name\` VARCHAR(50) NOT NULL,               -- ชื่อเรียกในเกม (IGN)
    \`primary_role\` VARCHAR(50) NOT NULL,               -- ตำแหน่ง/เลนหลักที่ถนัดในเกม RoV
    \`game_score\` INT DEFAULT 0,                        -- คะแนนดิบจากการทดสอบ (ค่าเริ่มต้นเป็น 0)
    \`created_at\` TIMESTAMP DEFAULT CURRENT_TIMESTAMP    -- วันและเวลาที่ลงชื่อสมัคร
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;`
  },
  {
    name: "db.php",
    language: "php",
    description: "สคริปต์เชื่อมต่อฐานข้อมูล MySQL ด้วยเทคโนโลยี PDO พร้อมระบบ Try-Catch ดักจับข้อผิดพลาด",
    content: `<?php
/**
 * ไฟล์เชื่อมต่อฐานข้อมูล MySQL (UDRU E-sports Registration)
 * ใช้งานเทคโนโลยี PDO (PHP Data Objects) ซึ่งมีความปลอดภัยและป้องกัน SQL Injection ได้ดีที่สุด
 */

$host = "localhost";        // ที่อยู่ของฐานข้อมูล (สำหรับ XAMPP บนเครื่องตนเองคือ localhost)
$db_name = "udru_esports";  // ชื่อฐานข้อมูลที่ตั้งค่าใน database.sql
$username = "root";         // ชื่อผู้ใช้งานดีฟอลต์ของ XAMPP
$password = "";             // รหัสผ่านเข้าฐานข้อมูล (ดีฟอลต์ของ XAMPP บน Windows จะเว้นว่างไว้)

try {
    // 1. เริ่มต้นเชื่อมต่อฐานข้อมูลโดยระบุที่อยู่, ชื่อ db และเลือกใช้ภาษา utf8mb4 สำหรับรองรับภาษาไทย
    $conn = new PDO("mysql:host=$host;dbname=$db_name;charset=utf8mb4", $username, $password);
    
    // 2. ตั้งค่าให้แสดง Exception เมื่อเกิดข้อผิดพลาดในการรัน SQL ป้องกันการปิดบัง error ที่ตรวจพบยาก
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    
    // 3. ตั้งค่า Fetch mode ดีฟอลต์ให้คืนค่าเป็นอะเรย์เชื่อมโยงแบบคีย์เป็นชื่อฟิลด์ (Associative Array)
    $conn->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    
    // 4. บังคับปิดจำลอง Prepare Statements เพื่อความปลอดภัยระดับสูงสุดจาก SQL Injection
    $conn->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

} catch (PDOException $e) {
    // ดักจับและยกเลิกกระบวนการทำงานทันทีหากเชื่อมต่อล้มเหลว พร้อมแสดงข้อความเตือนความผิดพลาด
    die("เชื่อมต่อฐานข้อมูลล้มเหลวกรุณาตรวจสอบว่าเปิด MySQL ใน XAMPP Control Panel แล้วหรือยัง? <br><b>ข้อความความผิดพลาด:</b> " . $e->getMessage());
}
?>`
  },
  {
    name: "index.php",
    language: "php",
    description: "หน้าแรกข้อมูลชมรม UDRU E-sports แสดงข่าวสาร สถิติความสำเร็จ และนำทางไปยังหน้าเข้าสู่ระบบและลงทะเบียนคัดตัว",
    content: `<?php
/**
 * หน้าข้อมูลชมรมหลัก (UDRU E-sports Portal - index.php)
 * ทำหน้าที่แสดงข้อมูลชมรม สถิติความสำเร็จ และให้ลิงก์เพื่อเข้าสู่ระบบหรือลงทะเบียนสมัครคัดตัวใหม่
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UDRU E-sports Club Portal</title>
    <!-- โหลด Tailwind CSS ผ่านระบบ CDN -->
    <script src="https://cdn.tailwindcss.com"></script>
    <!-- โหลดแบบอักษร Mitr (TH) และ Space Grotesk (EN) -->
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <style>
        body {
            font-family: 'Mitr', 'Space Grotesk', sans-serif;
        }
    </style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex flex-col justify-between relative overflow-x-hidden">
    
    <!-- พื้นหลังแอนิเมชัน Gradients และตาข่ายเส้นตาราง -->
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.12)_0%,rgba(0,0,0,1)_85%)] pointer-events-none -z-20"></div>
    <div class="absolute inset-0 opacity-15 pointer-events-none -z-10" style="background-image: linear-gradient(#334155 1px, transparent 1px), linear-gradient(90deg, #334155 1px, transparent 1px); background-size: 40px 40px;"></div>

    <!-- HEADER -->
    <header class="w-full h-20 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md flex items-center justify-between px-6 md:px-12">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span class="transform -rotate-45 font-black text-slate-950 text-xl font-mono">U</span>
            </div>
            <div>
                <h1 class="text-lg md:text-xl font-bold tracking-tighter uppercase italic text-cyan-400">UDRU E-SPORTS</h1>
                <p class="text-[9px] tracking-[0.2em] text-slate-400 uppercase font-mono">Official Club Portal</p>
            </div>
        </div>
        <div class="flex items-center gap-2">
            <span class="text-[9px] text-slate-500 uppercase font-mono">SYSTEM_STATUS</span>
            <span class="w-2.5 h-2.5 bg-emerald-400 rounded-full animate-pulse shadow-[0_0_8px_rgba(16,185,129,0.6)]"></span>
        </div>
    </header>

    <!-- MAIN PORTAL CONTENT -->
    <main class="max-w-4xl mx-auto py-16 px-6 space-y-12 relative z-10 flex-grow">
        
        <!-- Welcome Hero Section -->
        <div class="text-center space-y-4">
            <span class="px-3 py-1 bg-cyan-950/60 text-cyan-400 border border-cyan-800 text-xs font-mono rounded-full tracking-wider uppercase">// WELCOME TO THE ARENA</span>
            <h2 class="text-3xl md:text-5xl font-black italic text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-200 to-cyan-400 uppercase tracking-tight">ชมรมอีสปอร์ต มหาวิทยาลัยราชภัฏอุดรธานี</h2>
            <p class="text-slate-400 max-w-2xl mx-auto text-sm leading-relaxed">
                แหล่งรวบรวมทักษะ พัฒนาฝีมือ และยกระดับนักศึกษาสู่ระดับการแข่งขันมืออาชีพ <br>
                ก้าวเข้ามาเพื่อเป็นส่วนหนึ่งของทีมคัดตัวตัวจริง มาร่วมทดสอบปฏิกิริยาการตอบสนองความไวด้วยระบบ AI ตรวจจับฝ่ามือ!
            </p>
        </div>

        <!-- Statistics Grid -->
        <div class="grid grid-cols-1 md:grid-cols-3 gap-6">
            <div class="bg-black/40 border border-slate-900 p-6 rounded-xl text-center backdrop-blur-sm">
                <div class="text-2xl font-black text-cyan-400 mb-1">3+ เหรียญทอง</div>
                <div class="text-xs text-slate-400">กีฬามหาวิทยาลัยราชภัฏแห่งประเทศไทย</div>
            </div>
            <div class="bg-black/40 border border-slate-900 p-6 rounded-xl text-center backdrop-blur-sm">
                <div class="text-2xl font-black text-emerald-400 mb-1">150+ สมาชิก</div>
                <div class="text-xs text-slate-400">จากทุกคณะร่วมสร้างสรรค์คอมมูนิตี้</div>
            </div>
            <div class="bg-black/40 border border-slate-900 p-6 rounded-xl text-center backdrop-blur-sm">
                <div class="text-2xl font-black text-amber-500 mb-1">AI Hand Tracker</div>
                <div class="text-xs text-slate-400">ระบบคัดเลือกนวัตกรรมตรวจจับด้วยกล้อง</div>
            </div>
        </div>

        <!-- Recruitment CTA Area -->
        <div class="bg-black/60 border-2 border-cyan-500/20 p-8 rounded-xl text-center relative overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.1)]">
            <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-500 rounded-tl"></div>
            <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-500 rounded-tr"></div>
            <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-500 rounded-bl"></div>
            <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-500 rounded-br"></div>
            
            <h3 class="text-xl md:text-2xl font-bold uppercase text-white tracking-tight italic mb-3">ระบบสมัครและทดสอบคัดเลือกนักกีฬา</h3>
            <p class="text-xs text-slate-400 max-w-lg mx-auto mb-6 leading-relaxed">
                หากต้องการเข้าร่วมการทดสอบประสาทสัมผัส (Reflex Challenge) เพื่อบันทึกสถิติลงตารางผู้ท้าชิงของชมรม กรุณาเข้าสู่ระบบด้วยรหัสนักศึกษา หรือลงทะเบียนสมัครคัดตัวรายใหม่
            </p>

            <div class="flex flex-col sm:flex-row gap-4 justify-center max-w-md mx-auto">
                <a href="login.php" class="flex-1 py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black text-xs uppercase italic tracking-widest rounded transition-all transform hover:scale-[1.02] text-center flex items-center justify-center">
                    เข้าสู่ระบบด้วยรหัสเดิม (LOGIN)
                </a>
                <a href="register.php" class="flex-1 py-3.5 border border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 font-black text-xs uppercase italic tracking-widest rounded transition-all text-center flex items-center justify-center">
                    สมัครคัดตัวใหม่ (REGISTER)
                </a>
            </div>
        </div>
    </main>

    <!-- FOOTER -->
    <footer class="w-full h-12 bg-slate-900/40 border-t border-slate-900 flex items-center justify-center text-[10px] text-slate-500 tracking-[0.2em] uppercase text-center font-mono">
        © 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี
    </footer>
</body>
</html>`
  },
  {
    name: "login.php",
    language: "php",
    description: "หน้าฟอร์มเข้าสู่ระบบโดยการระบุรหัสนักศึกษาเดิม ดึงประวัติจาก MySQL และพาส่งไปยังหน้ามินิเกมทดสอบ",
    content: `<?php
/**
 * หน้าลงชื่อเข้าสู่ระบบของชมรม (login.php)
 * สำหรับให้นักศึกษาที่เคยสมัครไว้แล้วเข้ามาทดสอบคะแนนเพิ่มสถิติเดิมโดยไม่ต้องสมัครซ้ำ
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';

    if (empty($student_id)) {
        $error_msg = "กรุณากรอกรหัสนักศึกษา!";
    } else {
        try {
            // ตรวจสอบข้อมูลรหัสนักศึกษาในฐานข้อมูล MySQL
            $check_sql = "SELECT id, fullname FROM rov_applicants WHERE student_id = :student_id LIMIT 1";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([':student_id' => $student_id]);
            
            if ($check_stmt->rowCount() > 0) {
                // หากพบข้อมูล: เซฟสถานะใส่เซสชัน และนำทางไปเล่นเกม
                $user = $check_stmt->fetch();
                $_SESSION['applicant_id'] = $user['id'];
                $_SESSION['student_id'] = $student_id;
                $_SESSION['fullname'] = $user['fullname'];
                
                header("Location: game.html");
                exit();
            } else {
                $error_msg = "ไม่พบรหัสนักศึกษานี้ในระบบ! กรุณาตรวจสอบรหัสอีกครั้ง หรือกด 'สมัครใหม่' เพื่อลงทะเบียน";
            }
        } catch (PDOException $e) {
            $error_msg = "ฐานข้อมูลเชื่อมต่อล้มเหลว: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>เข้าสู่ระบบคัดตัว UDRU E-sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Mitr', 'Space Grotesk', sans-serif; }</style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex flex-col justify-between relative overflow-x-hidden">
    
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.12)_0%,rgba(0,0,0,1)_85%)] pointer-events-none -z-20"></div>
    
    <!-- HEADER -->
    <header class="w-full h-20 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md flex items-center justify-between px-6">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span class="transform -rotate-45 font-black text-slate-950 text-xl font-mono">U</span>
            </div>
            <h1 class="text-lg md:text-xl font-bold tracking-tighter uppercase italic text-cyan-400">UDRU E-SPORTS</h1>
        </div>
        <a href="index.php" class="text-xs text-slate-400 hover:text-cyan-400 transition-colors font-mono">← BACK PORTAL</a>
    </header>

    <!-- LOGIN FORM -->
    <main class="flex-grow flex items-center justify-center py-12 px-4 relative z-10">
        <div class="w-full max-w-md bg-black/60 border-2 border-cyan-500/30 p-8 rounded-xl relative shadow-[0_0_50px_rgba(6,182,212,0.15)]">
            
            <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-500 rounded-tl"></div>
            <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-500 rounded-tr"></div>
            <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-500 rounded-bl"></div>
            <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-500 rounded-br"></div>

            <h2 class="text-2xl font-black italic text-center uppercase text-white mb-2">เข้าสู่ระบบผู้สมัคร</h2>
            <p class="text-center text-xs text-slate-400 mb-6">ระบุรหัสนักศึกษาของคุณเพื่อยืนยันประวัติการคัดตัว</p>

            <?php if (!empty($error_msg)): ?>
                <div class="mb-5 p-3 rounded bg-red-950/40 border border-red-500/30 text-red-300 text-xs text-center">
                    ⚠️ <?php echo htmlspecialchars($error_msg); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-5">
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">รหัสนักศึกษา (Student ID)</label>
                    <input 
                        type="text" 
                        name="student_id" 
                        required 
                        placeholder="66390100XX" 
                        class="w-full px-4 py-2.5 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm transition-all text-slate-200 font-mono"
                    >
                </div>

                <button type="submit" class="w-full py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic text-xs tracking-widest rounded transform -skew-x-12 transition-all shadow-[0_5px_15px_rgba(6,182,212,0.3)]">
                    ดึงประวัติเดิม &amp; เริ่มคัดตัว 🚀
                </button>
            </form>

            <div class="mt-6 text-center text-xs text-slate-400">
                ยังไม่เคยลงทะเบียนสมัครคัดเลือก? <a href="register.php" class="text-cyan-400 hover:underline">สมัครคัดเลือกใหม่ที่นี่</a>
            </div>
        </div>
    </main>

    <footer class="w-full h-12 bg-slate-900/40 border-t border-slate-900 flex items-center justify-center text-[10px] text-slate-500 tracking-[0.2em] uppercase text-center font-mono">
        © 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี
    </footer>
</body>
</html>`
  },
  {
    name: "register.php",
    language: "php",
    description: "หน้าฟอร์มรับลงทะเบียนสมัครคัดเลือกนักกีฬาคนใหม่ บันทึกข้อมูลลง MySQL และพาส่งต่อไปยังหน้ามินิเกมทดสอบ",
    content: `<?php
/**
 * หน้าสมัครสมาชิกผู้สมัครรายใหม่ (register.php)
 * บันทึกประวัติเบื้องต้น ท่าทาง ตำแหน่งที่ถนัด เข้าตาราง MySQL และส่งต่อไปยังหน้าเกมทดสอบ
 */
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}
require_once 'db.php';

$error_msg = "";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $student_id = isset($_POST['student_id']) ? trim($_POST['student_id']) : '';
    $fullname = isset($_POST['fullname']) ? trim($_POST['fullname']) : '';
    $in_game_name = isset($_POST['in_game_name']) ? trim($_POST['in_game_name']) : '';
    $primary_role = isset($_POST['primary_role']) ? trim($_POST['primary_role']) : '';

    if (empty($student_id) || empty($fullname) || empty($in_game_name) || empty($primary_role)) {
        $error_msg = "กรุณากรอกข้อมูลให้ครบถ้วนทุกช่อง!";
    } else {
        try {
            // ตรวจสอบในฐานข้อมูลว่า รหัสนักศึกษาคนนี้เคยลงทะเบียนสมัครหรือยัง
            $check_sql = "SELECT id, fullname FROM rov_applicants WHERE student_id = :student_id LIMIT 1";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([':student_id' => $student_id]);
            
            if ($check_stmt->rowCount() > 0) {
                // หากพบข้อมูลเดิม: ให้ส่งไปที่เข้าสู่ระบบหรือดึงค่ามาใช้งานทันที
                $existing_user = $check_stmt->fetch();
                $_SESSION['applicant_id'] = $existing_user['id'];
                $_SESSION['student_id'] = $student_id;
                $_SESSION['fullname'] = $existing_user['fullname'];
                
                header("Location: game.html");
                exit();
            } else {
                // หากเป็นคนใหม่: บันทึกรายการสมัครลงตาราง rov_applicants คืนค่า id ล่าสุด
                $insert_sql = "INSERT INTO rov_applicants (student_id, fullname, in_game_name, primary_role, game_score) 
                               VALUES (:student_id, :fullname, :in_game_name, :primary_role, 0)";
                $insert_stmt = $conn->prepare($insert_sql);
                $insert_stmt->execute([
                    ':student_id' => $student_id,
                    ':fullname' => $fullname,
                    ':in_game_name' => $in_game_name,
                    ':primary_role' => $primary_role
                ]);
                
                $_SESSION['applicant_id'] = $conn->lastInsertId();
                $_SESSION['student_id'] = $student_id;
                $_SESSION['fullname'] = $fullname;
                
                header("Location: game.html");
                exit();
            }
        } catch (PDOException $e) {
            $error_msg = "ฐานข้อมูลเชื่อมต่อผิดพลาด: " . $e->getMessage();
        }
    }
}
?>
<!DOCTYPE html>
<html lang="th">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>ลงทะเบียนคัดตัว UDRU E-sports</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    <style>body { font-family: 'Mitr', 'Space Grotesk', sans-serif; }</style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex flex-col justify-between relative overflow-x-hidden">
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.12)_0%,rgba(0,0,0,1)_85%)] pointer-events-none -z-20"></div>
    
    <!-- HEADER -->
    <header class="w-full h-20 border-b border-cyan-500/20 bg-black/50 backdrop-blur-md flex items-center justify-between px-6">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span class="transform -rotate-45 font-black text-slate-950 text-xl font-mono">U</span>
            </div>
            <h1 class="text-lg md:text-xl font-bold tracking-tighter uppercase italic text-cyan-400">UDRU E-SPORTS</h1>
        </div>
        <a href="index.php" class="text-xs text-slate-400 hover:text-cyan-400 transition-colors font-mono">← BACK PORTAL</a>
    </header>

    <!-- REGISTER FORM -->
    <main class="flex-grow flex items-center justify-center py-12 px-4 relative z-10">
        <div class="w-full max-w-md bg-black/60 border-2 border-cyan-500/30 p-8 rounded-xl relative shadow-[0_0_50px_rgba(6,182,212,0.15)]">
            
            <div class="absolute top-0 left-0 w-4 h-4 border-t-2 border-l-2 border-cyan-500 rounded-tl"></div>
            <div class="absolute top-0 right-0 w-4 h-4 border-t-2 border-r-2 border-cyan-500 rounded-tr"></div>
            <div class="absolute bottom-0 left-0 w-4 h-4 border-b-2 border-l-2 border-cyan-500 rounded-bl"></div>
            <div class="absolute bottom-0 right-0 w-4 h-4 border-b-2 border-r-2 border-cyan-500 rounded-br"></div>

            <h2 class="text-2xl font-black italic text-center uppercase text-white mb-2">สมัครคัดเลือกใหม่</h2>
            <p class="text-center text-xs text-slate-400 mb-6">กรอกประวัติเบื้องต้นเพื่อเชื่อมโยงกับฐานข้อมูลของชมรม</p>

            <?php if (!empty($error_msg)): ?>
                <div class="mb-5 p-3 rounded bg-red-950/40 border border-red-500/30 text-red-300 text-xs text-center">
                    ⚠️ <?php echo htmlspecialchars($error_msg); ?>
                </div>
            <?php endif; ?>

            <form method="POST" action="" class="space-y-4">
                <!-- รหัสนักศึกษา -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">รหัสนักศึกษา (Student ID)</label>
                    <input 
                        type="text" 
                        name="student_id" 
                        required 
                        pattern="[0-9\-]+"
                        placeholder="66390100XX" 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200 font-mono"
                    >
                </div>

                <!-- ชื่อจริง -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">ชื่อ - นามสกุลจริง (Fullname)</label>
                    <input 
                        type="text" 
                        name="fullname" 
                        required 
                        placeholder="สมชาย เก่งกล้า" 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200"
                    >
                </div>

                <!-- ชื่อในเกม -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">ชื่อเรียกในเกม (In-Game Name)</label>
                    <input 
                        type="text" 
                        name="in_game_name" 
                        required 
                        placeholder="UDRU_CarryGod" 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200"
                    >
                </div>

                <!-- ตำแหน่งถนัด -->
                <div>
                    <label class="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest mb-1.5 font-mono">ตำแหน่งที่ถนัด (Primary Role)</label>
                    <select 
                        name="primary_role" 
                        required 
                        class="w-full px-4 py-2 rounded bg-slate-900 border border-slate-800 focus:border-cyan-500 outline-none text-sm text-slate-200 cursor-pointer"
                    >
                        <option value="">-- เลือกหน้าที่หลัก --</option>
                        <option value="Abyssal Dragon Lane (Carry)">Abyssal Dragon Lane (Carry) - แครี่ดาเมจ</option>
                        <option value="Dark Slayer Lane (Fighter)">Dark Slayer Lane (Fighter) - ออฟเลนถึกทน</option>
                        <option value="Middle Lane (Mage)">Middle Lane (Mage) - เมจเวทควบคุม</option>
                        <option value="Jungle (Assassin)">Jungle (Assassin) - ป่าโจมตีฉับไว</option>
                        <option value="Roaming (Support/Tank)">Roaming (Support/Tank) - ซัพพอร์ตปกป้องเพื่อน</option>
                    </select>
                </div>

                <button type="submit" class="w-full py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic text-xs tracking-widest rounded transform -skew-x-12 transition-all shadow-[0_5px_15px_rgba(6,182,212,0.3)] pt-3">
                    บันทึกข้อมูลสมัคร &amp; เริ่มสอบ 🚀
                </button>
            </form>

            <div class="mt-6 text-center text-xs text-slate-400 font-sans">
                มีประวัติสมัครอยู่แล้ว? <a href="login.php" class="text-cyan-400 hover:underline">เข้าสู่ระบบที่นี่</a>
            </div>
        </div>
    </main>

    <footer class="w-full h-12 bg-slate-900/40 border-t border-slate-900 flex items-center justify-center text-[10px] text-slate-500 tracking-[0.2em] uppercase text-center font-mono">
        © 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี
    </footer>
</body>
</html>`
  },
  {
    name: "update_score.php",
    language: "php",
    description: "API หลังบ้านที่รับคะแนนแบบ JSON ผ่าน Fetch API แล้วบันทึกทับลงในฐานข้อมูลผู้สมัคร",
    content: `<?php
/**
 * ไฟล์ PHP สำหรับอัปเดตคะแนนผ่าน AJAX/Fetch API
 * รับข้อมูลแบบ JSON POST เข้ามาตรวจสอบเซสชัน และเซฟคะแนนผู้สมัครลงฐานข้อมูล
 */

// 1. เริ่มเซสชันเพื่อดึง ID ตัวตนผู้สมัครที่ลงชื่อไว้ในหน้า index.php
if (session_status() == PHP_SESSION_NONE) {
    session_start();
}

// 2. ตั้งค่าการส่งข้อมูลกลับเป็น JSON
header('Content-Type: application/json; charset=utf-8');

// 3. นำเข้าไฟล์เชื่อมต่อฐานข้อมูล PDO
require_once 'db.php';

// 4. ตรวจสอบว่าส่งคำขอเข้าแบบ POST หรือไม่
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
    // ดึงข้อมูลดิบจากส่วนเนื้อหาคำขอ (Request Body) ที่ส่งมาเป็น JSON
    $json_raw = file_get_contents('php://input');
    $data = json_decode($json_raw, true);
    
    // ตรวจสอบความถูกต้องของคะแนนที่ได้ และสถานะความเชื่อมโยงในเซสชัน
    if (isset($data['score']) && isset($_SESSION['applicant_id'])) {
        $score = intval($data['score']);
        $applicant_id = intval($_SESSION['applicant_id']);
        
        try {
            // ดึงคะแนนเดิมขึ้นมาเปรียบเทียบ (เพื่อให้บันทึกคะแนนสูงสุดที่ดีที่สุด หรือจะเขียนทับไปเลย)
            $check_sql = "SELECT game_score FROM rov_applicants WHERE id = :id";
            $check_stmt = $conn->prepare($check_sql);
            $check_stmt->execute([':id' => $applicant_id]);
            $applicant = $check_stmt->fetch();
            
            if ($applicant) {
                // หากคะแนนใหม่สูงกว่าคะแนนเดิม ให้ทำบันทึกทับเพื่อป้องกันผู้คัดสมัครโกงคะแนนย้อนหลัง
                $best_score = max($score, intval($applicant['game_score']));
                
                $update_sql = "UPDATE rov_applicants SET game_score = :score WHERE id = :id";
                $update_stmt = $conn->prepare($update_sql);
                $update_stmt->execute([
                    ':score' => $best_score,
                    ':id' => $applicant_id
                ]);
                
                // ตอบกลับความสำเร็จเป็นรูปแบบ JSON ให้ฝั่ง JavaScript นำไปประมวลผลต่อ
                echo json_encode([
                    'success' => true,
                    'message' => 'บันทึกคะแนนสะสมความไวลงสู่ฐานข้อมูล UDRU สำเร็จ!',
                    'score' => $best_score
                ]);
                exit();
            } else {
                echo json_encode([
                    'success' => false,
                    'message' => 'ไม่พบข้อมูลรหัสผู้ลงสมัครในฐานข้อมูล!'
                ]);
                exit();
            }
        } catch (PDOException $e) {
            echo json_encode([
                'success' => false,
                'message' => 'ฐานข้อมูลผิดพลาด: ' . $e->getMessage()
            ]);
            exit();
        }
    } else {
        echo json_encode([
            'success' => false,
            'message' => 'พารามิเตอร์ผิดพลาด! ไม่พบคะแนนที่ส่งเข้ามา หรือเซสชันหมดอายุ กรุณาลงทะเบียนใหม่อีกครั้ง'
        ]);
        exit();
    }
} else {
    echo json_encode([
        'success' => false,
        'message' => 'รองรับเฉพาะคำขอแบบ POST เท่านั้น!'
    ]);
    exit();
}
?>`
  },
  {
    name: "game.html",
    language: "html",
    description: "มินิเกม AI สรรหาผู้ตรวจจับฝ่ามือด้วย MediaPipe Hands ที่จะยิง AJAX (Fetch API) เข้าเซฟคะแนนหลังเล่นจบ",
    content: `<!DOCTYPE html>
<html lang="th" class="h-full">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>UDRU E-sports - ห้องทดสอบปฏิกิริยาการตอบสนอง</title>
    
    <!-- โหลด Tailwind CSS ผ่านระบบ CDN สำหรับการจัดโครงร่างสีและการแบ่งเฟรม -->
    <script src="https://cdn.tailwindcss.com"></script>
    
    <!-- โหลดไลบรารีวิเคราะห์ตำแหน่งอวัยวะและจุดพิกัดฝ่ามือของ MediaPipe Hands ผ่าน CDN อย่างเป็นทางการ -->
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/camera_utils/camera_utils.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/hands/hands.js" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/@mediapipe/drawing_utils/drawing_utils.js" crossorigin="anonymous"></script>
    
    <!-- ฟอนต์ Mitr (TH) และ Space Grotesk (EN) เพิ่มความมีชีวิตชีวา ดุดัน และดูน่าเกรงขามสไตล์เกมเมอร์ -->
    <link href="https://fonts.googleapis.com/css2?family=Mitr:wght@300;400;500;600&family=Space+Grotesk:wght@500;700&display=swap" rel="stylesheet">
    
    <style>
        body {
            font-family: 'Mitr', 'Space Grotesk', sans-serif;
        }
        /* เอฟเฟกต์ฟิลเตอร์เลียนแบบเส้นทีวีสแกนเนอร์เพิ่มอารมณ์ Sci-Fi ล้ำลึก */
        .bg-scanlines {
            background: linear-gradient(
                rgba(18, 16, 16, 0) 50%, 
                rgba(0, 0, 0, 0.25) 50%
            ), linear-gradient(
                90deg, 
                rgba(255, 0, 0, 0.05), 
                rgba(0, 255, 0, 0.02), 
                rgba(0, 0, 255, 0.05)
            );
            background-size: 100% 4px, 6px 100%;
        }
    </style>
</head>
<body class="bg-slate-950 text-white min-h-screen flex flex-col justify-between relative overflow-x-hidden select-none">

    <!-- แบล็คกราวนด์ออร่าสีและตารางกริดเทคโนโลยีเว็บบนเบื้องหลัง -->
    <div class="absolute inset-0 bg-[radial-gradient(circle_at_center,rgba(6,182,212,0.15)_0%,rgba(0,0,0,1)_80%)] pointer-events-none -z-20"></div>
    <div class="absolute inset-0 opacity-15 pointer-events-none -z-10" style="background-image: linear-gradient(#334155 1px, transparent 1px), linear-gradient(90deg, #334155 1px, transparent 1px); background-size: 40px 40px;"></div>

    <!-- ================= HEADER BAR ================= -->
    <header class="relative z-10 w-full h-20 border-b border-cyan-500/30 bg-black/60 backdrop-blur-md flex items-center justify-between px-6 md:px-12">
        <div class="flex items-center gap-4">
            <div class="w-11 h-11 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_15px_rgba(6,182,212,0.5)]">
                <span class="transform -rotate-45 font-black text-slate-950 text-xl font-mono">U</span>
            </div>
            <div>
                <h1 class="text-lg md:text-xl font-bold tracking-tighter uppercase italic text-cyan-400">UDRU E-SPORTS</h1>
                <p class="text-[9px] tracking-[0.2em] text-slate-400 uppercase font-mono">Catch the Logo Challenge // AI Test</p>
            </div>
        </div>
        <div id="connection-status" class="flex items-center gap-2 px-3.5 py-1.5 bg-slate-900 border border-slate-800 rounded">
            <span class="h-2.5 w-2.5 rounded-full bg-cyan-500 animate-pulse shadow-[0_0_8px_#06b6d4]"></span>
            <span class="text-[10px] font-mono text-cyan-400 uppercase font-bold tracking-wider">MediaPipe Connected</span>
        </div>
    </header>

    <!-- ================= MAIN TEST INTERACTION STAGE ================= -->
    <main class="relative z-10 flex-grow flex flex-col items-center justify-center p-4">
        <div class="w-full max-w-3xl flex flex-col items-center gap-5">
            
            <!-- ตารางสถิติผู้เข้าทดสอบแบบ Real-time (HUD) -->
            <div class="w-full flex justify-between gap-4">
                <div class="p-4 bg-black/60 border-l-4 border-cyan-500 backdrop-blur-md flex-1 rounded-r-lg">
                    <div class="text-[9px] text-slate-400 font-mono tracking-widest uppercase">Current Score</div>
                    <div id="score-display" class="text-3xl font-black font-mono text-white tracking-tighter italic">0 <span class="text-xs text-slate-400 font-normal font-sans not-italic">PTS</span></div>
                </div>
                <div class="p-4 bg-black/60 border-r-4 border-red-500 backdrop-blur-md text-right flex-1 rounded-l-lg">
                    <div class="text-[9px] text-slate-400 font-mono tracking-widest uppercase">Time Remaining</div>
                    <div id="timer-display" class="text-3xl font-black font-mono text-red-500 tracking-tighter italic">00:60</div>
                </div>
            </div>

            <!-- กล่องโครงกล้องแคนวาสจำลองการคัดเลือก (Camera Box Area) -->
            <div class="w-full aspect-[4/3] bg-slate-950/40 rounded-xl border-4 border-slate-800 relative overflow-hidden shadow-[0_0_50px_rgba(6,182,212,0.1)]">
                
                <!-- ขอบมุม Cyber Tech สำหรับกรอบเล็งเป้า -->
                <div class="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-cyan-500 rounded-tl-lg z-20"></div>
                <div class="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-cyan-500 rounded-tr-lg z-20"></div>
                <div class="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-cyan-500 rounded-bl-lg z-20"></div>
                <div class="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-cyan-500 rounded-br-lg z-20"></div>

                <!-- แท็กดึงสัญญาณวิดีโอจากกล้อง (ซ่อนไว้เนื่องจากจะไปประมวลผลวาดลงแคนวาสแทน) -->
                <video id="webcam-video" class="absolute inset-0 w-full h-full object-cover scale-x-[-1]" playsinline muted style="display: none;"></video>
                
                <!-- แคนวาสสำหรับเรนเดอร์ภาพจากกล้องและโครงเส้นกระดูกมือที่ตรวจพบ -->
                <canvas id="render-canvas" class="absolute inset-0 w-full h-full object-cover scale-x-[-1] z-10"></canvas>
                
                <!-- แถบสเกลเอฟเฟกต์ทีวีเก่าสแกนลอน -->
                <div class="absolute inset-0 bg-scanlines opacity-10 pointer-events-none z-15"></div>

                <!-- หน้าจอต้อนรับหน้าเล็บบี้เตรียมความพร้อม (Lobby State) -->
                <div id="start-overlay" class="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-30 text-center p-6">
                    <div class="w-16 h-16 bg-red-600 rounded-xl transform rotate-45 border-4 border-white shadow-[0_0_30px_rgba(220,38,38,0.6)] mb-6 animate-pulse flex items-center justify-center">
                        <span class="transform -rotate-45 font-black text-2xl text-white">RoV</span>
                    </div>
                    <h3 class="text-2xl font-black text-cyan-400 tracking-wider">ห้องจำลองการทดสอบฝ่ามือ AI</h3>
                    <p class="text-xs text-slate-400 max-w-md mt-2 mb-8 leading-relaxed">
                        ระบบจะใช้เทคโนโลยีประมวลผลภาพขั้นสูงในเบราว์เซอร์ของคุณเพื่อวิเคราะห์ตำแหน่งฝ่ามือโดยไม่ต้องใช้สายหรือเมาส์ <br>
                        <b class="text-cyan-300">วิธีเล่น:</b> ขยับปลายนิ้วชี้ของคุณไปสัมผัสกับเป้าหมายโลโก้ RoV บนจอเพื่อทำแต้มให้เร็วที่สุดภายในเวลา 60 วินาที!
                    </p>
                    <button id="btn-start" class="px-8 py-4 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic tracking-widest rounded-sm transform -skew-x-12 transition-all shadow-[0_10px_25px_rgba(6,182,212,0.4)] cursor-pointer">
                        <span class="inline-block transform skew-x-12">เข้าสู่การทดสอบความเร็ว</span>
                    </button>
                    <p id="error-message" class="text-xs text-red-400 mt-4 max-w-sm hidden"></p>
                </div>

                <!-- วัตถุเป้าหมายโลโก้ RoV ทรงสี่เหลี่ยมเอียงแบบหมุน (Target Node) -->
                <div id="rov-target" class="absolute z-20 pointer-events-none transform -translate-x-1/2 -translate-y-1/2 transition-all duration-300 ease-out" style="display: none; width: 75px; height: 75px;">
                    <div class="relative w-full h-full flex items-center justify-center">
                        <div class="absolute inset-0 bg-red-600 rounded-xl transform rotate-45 border-4 border-white shadow-[0_0_25px_rgba(220,38,38,0.7)]"></div>
                        <div class="absolute inset-0 bg-red-600/30 rounded-xl transform rotate-45 scale-125 animate-ping"></div>
                        <div class="relative transform -rotate-45 z-10 font-black text-sm text-white font-mono tracking-tighter">RoV</div>
                    </div>
                </div>

                <!-- หน้าจอแช่แข็งเตือนถอยหลังเริ่มเกม (3.. 2.. 1.. GO!) -->
                <div id="countdown-overlay" class="absolute inset-0 bg-black/90 flex flex-col items-center justify-center z-35" style="display: none;">
                    <div class="text-center">
                        <p class="text-xs font-mono tracking-widest text-cyan-400 uppercase animate-pulse mb-2">SYSTEM SYNCHRONIZATION ACTIVE</p>
                        <h1 id="countdown-number" class="text-9xl font-black text-transparent bg-clip-text bg-gradient-to-b from-cyan-300 to-cyan-600 font-mono tracking-tight animate-ping">3</h1>
                    </div>
                </div>

                <!-- หน้าจอบันทึกคะแนนหลังสอบเสร็จและป๊อปอัพเซฟ (Game Over Modal) -->
                <div id="gameover-overlay" class="absolute inset-0 bg-black/95 flex flex-col items-center justify-center z-30 text-center p-6" style="display: none;">
                    <div class="w-14 h-14 rounded-full bg-red-500/10 border border-red-500/40 flex items-center justify-center mb-2 mx-auto">
                        <span class="text-red-500 font-bold text-xs font-mono">TIME_UP</span>
                    </div>
                    <h3 class="text-3xl font-black text-white uppercase tracking-tight italic">หมดเวลาทดสอบคัดเลือก!</h3>
                    <p class="text-xs text-slate-400 mt-1">สถิติอัตราตอบสนองการเคลียร์เป้าหมายทั้งหมดที่ทำได้</p>
                    
                    <div class="my-6 p-5 bg-slate-900/60 border border-slate-800 rounded-lg max-w-xs mx-auto">
                        <span class="text-[10px] text-slate-500 font-mono tracking-widest block uppercase">FINAL SCORE</span>
                        <h2 id="final-score" class="text-6xl font-black text-cyan-400 font-mono tracking-tighter italic my-1">0</h2>
                        <span class="text-[10px] text-slate-400 block font-mono">TOTAL CATCHES // 60 SECONDS</span>
                    </div>

                    <!-- แถวปุ่มสำหรับยิง AJAX / Fetch API และเล่นซ้ำ -->
                    <div class="flex flex-col sm:flex-row gap-3 justify-center w-full max-w-sm mx-auto">
                        <button id="btn-submit" class="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black uppercase italic tracking-widest rounded-sm transform -skew-x-12 transition-all shadow-[0_5px_15px_rgba(16,185,129,0.3)] cursor-pointer flex-1">
                            <span class="inline-block transform skew-x-12 font-bold text-xs">บันทึกคะแนน (SAVE)</span>
                        </button>
                        <button id="btn-retry" class="px-6 py-3.5 border border-slate-700 hover:bg-white/10 text-white font-black uppercase italic tracking-widest rounded-sm transform -skew-x-12 transition-all flex-1 cursor-pointer">
                            <span class="inline-block transform skew-x-12 font-bold text-xs">ทดสอบรอบใหม่</span>
                        </button>
                    </div>
                    <p id="submit-status" class="text-xs font-mono mt-4 text-slate-300 transition-all"></p>
                </div>
            </div>
            
            <div class="flex w-full justify-between items-center text-[10px] text-slate-500 font-mono px-2">
                <span>MODEL COMPLEXITY: 1_AUTO</span>
                <span>LATENCY: ~16ms</span>
            </div>
        </div>
    </main>

    <!-- ================= FOOTER ================= -->
    <footer class="relative z-10 w-full h-12 bg-slate-900/40 border-t border-slate-900 flex items-center justify-center px-10 text-[10px] uppercase tracking-[0.25em] text-slate-500 text-center font-mono">
        © 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี • พัฒนาขึ้นเพื่อทดสอบทักษะสากล
    </footer>

    <!-- ================= สคริปต์การทำงานของระบบเกม AI HAND TRACKING ================= -->
    <script>
        // --- 1. ประกาศตัวแปรควบคุมเกมและกล้อง ---
        let score = 0;
        let timeLeft = 60;
        let isPlaying = false;
        let gameTimer = null;
        let videoStream = null;
        let camera = null;

        // ตัวแปรเก็บพิกัดของเป้าหมายโลโก้ (กำหนดค่าเป็นอัตราส่วน 0.0 ถึง 1.0)
        let targetX = 0.5;
        let targetY = 0.5;

        // ผูกตัวแปรเข้ากับอิลิเมนต์ต่าง ๆ ในหน้าเว็บ
        const webcamVideo = document.getElementById('webcam-video');
        const renderCanvas = document.getElementById('render-canvas');
        const canvasCtx = renderCanvas.getContext('2d');
        const scoreDisplay = document.getElementById('score-display');
        const timerDisplay = document.getElementById('timer-display');
        const startOverlay = document.getElementById('start-overlay');
        const countdownOverlay = document.getElementById('countdown-overlay');
        const countdownNumber = document.getElementById('countdown-number');
        const gameoverOverlay = document.getElementById('gameover-overlay');
        const finalScore = document.getElementById('final-score');
        const rovTarget = document.getElementById('rov-target');
        const errorMessage = document.getElementById('error-message');
        const submitStatus = document.getElementById('submit-status');

        const btnStart = document.getElementById('btn-start');
        const btnSubmit = document.getElementById('btn-submit');
        const btnRetry = document.getElementById('btn-retry');

        // --- 2. ฟังก์ชันย้ายตำแหน่งเป้าหมายโลโก้ RoV แบบสุ่มหลีกเลี่ยงขอบหน้าจอ ---
        function relocateTarget() {
            // สุ่มตำแหน่งระหว่าง 15% ถึง 85% ของกรอบหน้าจอ
            targetX = 0.15 + Math.random() * 0.70;
            targetY = 0.15 + Math.random() * 0.70;
            
            // นำผลลัพธ์ไปประยุกต์ใช้กับ CSS Absolute Position
            rovTarget.style.left = (targetX * 100) + '%';
            rovTarget.style.top = (targetY * 100) + '%';
        }

        // --- 3. ฟังก์ชันเตรียมการเปิดกล้องและผูกระบบคัดกรองพิกัดมือ AI ---
        async function startTracking() {
            errorMessage.classList.add('hidden');
            btnStart.disabled = true;
            btnStart.innerHTML = "<span class='inline-block transform skew-x-12'>กำลังดึงโมเดลระบบ AI...</span>";

            try {
                // อนุมัติการเข้าใช้กล้องผ่านเบราว์เซอร์
                videoStream = await navigator.mediaDevices.getUserMedia({
                    video: { width: 640, height: 480 },
                    audio: false
                });
                webcamVideo.srcObject = videoStream;

                // โหลดโมเดลตรวจจับจุดตำแหน่งข้อต่อมือ (MediaPipe Hands)
                const hands = new Hands({
                    locateFile: (file) => \`https://cdn.jsdelivr.net/npm/@mediapipe/hands/\${file}\`
                });

                // กำหนดตัวแปรเสริมเพื่อความไหลลื่นและหน่วงเวลาการตรวจจับที่พอเหมาะ
                hands.setOptions({
                    maxNumHands: 1,                 // ค้นหามือเดียวเท่านั้นเพื่อหลีกเลี่ยงความหน่วงของซีพียู
                    modelComplexity: 1,             // ระดับความลึกของการคำนวณ (1 = รวดเร็วปานกลาง เหมาะสำหรับกล้องเว็บ)
                    minDetectionConfidence: 0.6,    // ความมั่นใจขั้นต่ำในการสแกนเริ่มมือ
                    minTrackingConfidence: 0.6       // ความมั่นใจขั้นต่ำในการลากเส้นตามรอยนิ้วมือ
                });

                hands.onResults(onResults);

                // เริ่มฟังก์ชันลูปดึงข้อมูลภาพจากอุปกรณ์กล้อง
                camera = new Camera(webcamVideo, {
                    onFrame: async () => {
                        await hands.send({ image: webcamVideo });
                    },
                    width: 640,
                    height: 480
                });

                await camera.start();
                
                // เข้าสู่โหมดนับถอยหลังก่อนเริ่ม 3 วินาที
                startCountdown();

            } catch (err) {
                console.error(err);
                let msg = "ไม่สามารถเปิดกล้องเว็บบอร์ดของคุณได้ กรุณาเชื่อมต่ออุปกรณ์และยอมรับสิทธิ์การเข้าใช้งานกล้อง";
                if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
                    msg = "กล้องถูกปฏิเสธสิทธิ์เข้าใช้งาน! กรุณาคลิกไอคอนรูปกุญแจบนที่อยู่เว็บเพื่อยินยอมเปิดกล้อง";
                }
                errorMessage.textContent = msg;
                errorMessage.classList.remove('hidden');
                btnStart.disabled = false;
                btnStart.innerHTML = "<span class='inline-block transform skew-x-12'>เข้าสู่การทดสอบความเร็ว</span>";
                stopCamera();
            }
        }

        // --- 4. ฟังก์ชันนับถอยหลังประสานปฏิกิริยาก่อนปล่อยตัวเล่น ---
        function startCountdown() {
            startOverlay.style.display = 'none';
            countdownOverlay.style.display = 'flex';
            let count = 3;
            countdownNumber.textContent = count;

            const countdownInterval = setInterval(() => {
                count--;
                if (count > 0) {
                    countdownNumber.textContent = count;
                } else if (count === 0) {
                    countdownNumber.textContent = "GO!";
                } else {
                    clearInterval(countdownInterval);
                    countdownOverlay.style.display = 'none';
                    startGameplay();
                }
            }, 1000);
        }

        // --- 5. ฟังก์ชันปล่อยตัวเล่นทดสอบจับคู่เป้าหมายโลโก้ ---
        function startGameplay() {
            isPlaying = true;
            score = 0;
            timeLeft = 60;
            
            scoreDisplay.innerHTML = score + " <span class='text-xs text-slate-400 font-normal font-sans not-italic'>PTS</span>";
            timerDisplay.textContent = "00:60";
            rovTarget.style.display = 'block';
            relocateTarget();

            // รันลูปหักเวลาทดสอบลง
            gameTimer = setInterval(() => {
                timeLeft--;
                timerDisplay.textContent = "00:" + (timeLeft < 10 ? "0" + timeLeft : timeLeft);
                if (timeLeft <= 0) {
                    handleGameOver();
                }
            }, 1000);
        }

        // --- 6. ฟังก์ชันเมื่อเวลาในการทดสอบสิ้นสุดลง ---
        function handleGameOver() {
            isPlaying = false;
            clearInterval(gameTimer);
            rovTarget.style.display = 'none';
            finalScore.textContent = score;
            gameoverOverlay.style.display = 'flex';
            submitStatus.textContent = "";
            btnSubmit.disabled = false;
            stopCamera();
        }

        // ฟังก์ชันสั่งปิดการทำงานของกล้องเพื่อเคลียร์ทรัพยากรเบราว์เซอร์
        function stopCamera() {
            if (camera) {
                try { camera.stop(); } catch(e) {}
                camera = null;
            }
            if (videoStream) {
                try { videoStream.getTracks().forEach(track => track.stop()); } catch(e) {}
                videoStream = null;
            }
        }

        // --- 7. ฟังก์ชันรับข้อมูลสแกนพิกัดกระดูกข้อต่อจาก AI และคำนวณการแตะเป้าหมาย ---
        function onResults(results) {
            if (!isPlaying) return;

            // คอยตั้งค่ากว้างยาวของแคนวาสให้ยืดหยุ่นสัมพันธ์ตามขนาดพื้นที่จอ
            if (renderCanvas.width !== renderCanvas.clientWidth || renderCanvas.height !== renderCanvas.clientHeight) {
                renderCanvas.width = renderCanvas.clientWidth;
                renderCanvas.height = renderCanvas.clientHeight;
            }

            const cw = renderCanvas.width;
            const ch = renderCanvas.height;

            // ลบเฟรมภาพเก่าของแคนวาสออกก่อนวาดเฟรมใหม่ทับ
            canvasCtx.clearRect(0, 0, cw, ch);

            // หากวิเคราะห์จุดพิกัดมือขึ้นได้สำเร็จ
            if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
                const landmarks = results.multiHandLandmarks[0];

                // วาดลายเส้นเชื่อมต่อทุกข้อมือและกระดูกนิ้วเป็นสไตล์นีออนเรืองแสง
                drawConnectors(canvasCtx, landmarks, HAND_CONNECTIONS, { color: '#06b6d4', lineWidth: 4 });
                drawLandmarks(canvasCtx, landmarks, { color: '#ef4444', lineWidth: 1, radius: 4 });

                // คัดพิกัดเฉพาะปลายนิ้วชี้ (Index Finger Tip // จุดลำดับที่ 8)
                const indexTip = landmarks[8];
                if (indexTip) {
                    // ทำการ Mirror ทิศทางแนวนอนสอดคล้องกับการเคลื่อนมือธรรมชาติของผู้ใช้
                    const visualX = 1 - indexTip.x;
                    const visualY = indexTip.y;

                    // วาดวงกลมตัวนำทางสายตา (Pointer Guide) เต้นเรืองแสงครอบปลายนิ้วชี้
                    canvasCtx.save();
                    canvasCtx.shadowBlur = 15;
                    canvasCtx.shadowColor = '#06b6d4';
                    canvasCtx.beginPath();
                    canvasCtx.arc(indexTip.x * cw, indexTip.y * ch, 18, 0, 2 * Math.PI);
                    canvasCtx.strokeStyle = '#22c55e';
                    canvasCtx.lineWidth = 3;
                    canvasCtx.stroke();
                    canvasCtx.restore();

                    // คำนวณความใกล้เคียงระหว่างปลายนิ้วชี้ของผู้เล่นกับเป้าหมายโลโก้ด้วยสูตรพิทาโกรัส
                    const dx = visualX - targetX;
                    const dy = visualY - targetY;
                    const distance = Math.sqrt(dx * dx + dy * dy);

                    // ถ้าระยะห่างน้อยกว่า 0.08 (8% ของสัดส่วนความกว้างของหน้าจอ) ถือว่าเคลียร์เป้าหมายสำเร็จ!
                    if (distance < 0.08) {
                        score++;
                        scoreDisplay.innerHTML = score + " <span class='text-xs text-slate-400 font-normal font-sans not-italic'>PTS</span>";
                        relocateTarget();
                    }
                }
            }
        }

        // --- 8. บันทึกคะแนนดิบที่ทำได้อัปเกรดส่งกลับฐานข้อมูล PHP (Fetch API / AJAX) ---
        async function submitScore() {
            btnSubmit.disabled = true;
            submitStatus.innerHTML = "<span class='text-cyan-400 animate-pulse'>กำลังประมวลผลเซสชันและอัปเดตข้อมูล...</span>";

            try {
                // ส่งค่าคะแนนดิบขึ้นไปด้วยรูปแบบ JSON ผ่านหัวข้อคำขอ POST
                const response = await fetch('update_score.php', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ score: score })
                });

                const result = await response.json();

                if (result.success) {
                    submitStatus.innerHTML = "<span class='text-emerald-400 font-bold'>✅ " + result.message + " (สถิติรวม: " + result.score + " PTS)</span>";
                } else {
                    submitStatus.innerHTML = "<span class='text-red-400 font-bold'>❌ " + result.message + "</span>";
                    btnSubmit.disabled = false;
                }
            } catch (err) {
                console.error(err);
                submitStatus.innerHTML = "<span class='text-red-400 font-bold'>❌ บันทึกคะแนนล้มเหลว! (กรุณาเช็กว่าระบบรันบน XAMPP Localhost แล้วหรือยัง?)</span>";
                btnSubmit.disabled = false;
            }
        }

        // ผูกความสัมพันธ์คำสั่งปุ่มต่าง ๆ
        btnStart.addEventListener('click', startTracking);
        btnSubmit.addEventListener('click', submitScore);
        btnRetry.addEventListener('click', () => {
            gameoverOverlay.style.display = 'none';
            startTracking();
        });
    </script>
</body>
</html>`
  }
];
