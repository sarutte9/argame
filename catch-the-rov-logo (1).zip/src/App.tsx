/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import { useState, useEffect, useRef, FormEvent } from 'react';
import { 
  Trophy, 
  Gamepad2, 
  Play, 
  RotateCcw, 
  Camera, 
  Timer, 
  Volume2, 
  VolumeX, 
  AlertTriangle,
  Sparkles,
  Info,
  Medal,
  Users,
  Database,
  Code,
  Copy,
  Download,
  Check,
  Terminal,
  ArrowRight,
  FileCode,
  RefreshCw,
  Trash2,
  ChevronRight,
  Lock,
  UserPlus,
  LogIn,
  ArrowLeft
} from 'lucide-react';
import { sourceFiles, SourceFile } from './sourceCode';

// ==========================================
// PURE WEB AUDIO SYNTHESIZER FOR GAME SOUNDS
// ==========================================
class SoundEffects {
  private static ctx: AudioContext | null = null;
  public static isMuted = false;

  private static init() {
    if (!this.ctx) {
      this.ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  static playCatch() {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(523.25, this.ctx.currentTime); // C5
      osc.frequency.exponentialRampToValueAtTime(1046.50, this.ctx.currentTime + 0.12); // C6
      
      gain.gain.setValueAtTime(0.15, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.15);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start();
      osc.stop(this.ctx.currentTime + 0.15);
    } catch (e) {
      console.warn("Audio failed to play", e);
    }
  }

  static playStart() {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      
      const now = this.ctx.currentTime;
      const notes = [261.63, 329.63, 392.00, 523.25]; // C4, E4, G4, C5
      notes.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        
        osc.type = 'triangle';
        osc.frequency.setValueAtTime(freq, now + i * 0.08);
        
        gain.gain.setValueAtTime(0.1, now + i * 0.08);
        gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.08 + 0.25);
        
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        
        osc.start(now + i * 0.08);
        osc.stop(now + i * 0.08 + 0.25);
      });
    } catch (e) {
      console.warn("Audio failed to play", e);
    }
  }

  static playClick() {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(440, this.ctx.currentTime); // A4
      
      gain.gain.setValueAtTime(0.08, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.06);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start();
      osc.stop(this.ctx.currentTime + 0.06);
    } catch (e) {
      console.warn("Audio failed to play", e);
    }
  }

  static playCountdown() {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      
      const osc = this.ctx.createOscillator();
      const gain = this.ctx.createGain();
      
      osc.type = 'sine';
      osc.frequency.setValueAtTime(392.00, this.ctx.currentTime); // G4
      
      gain.gain.setValueAtTime(0.12, this.ctx.currentTime);
      gain.gain.exponentialRampToValueAtTime(0.01, this.ctx.currentTime + 0.15);
      
      osc.connect(gain);
      gain.connect(this.ctx.destination);
      
      osc.start();
      osc.stop(this.ctx.currentTime + 0.15);
    } catch (e) {
      console.warn("Audio failed to play", e);
    }
  }

  static playGameOver() {
    if (this.isMuted) return;
    try {
      this.init();
      if (!this.ctx) return;
      
      const now = this.ctx.currentTime;
      const notes = [392.00, 349.23, 311.13, 261.63]; // G4, F4, Eb4, C4
      notes.forEach((freq, i) => {
        const osc = this.ctx!.createOscillator();
        const gain = this.ctx!.createGain();
        
        osc.type = 'sawtooth';
        osc.frequency.setValueAtTime(freq, now + i * 0.15);
        
        gain.gain.setValueAtTime(0.12, now + i * 0.15);
        gain.gain.exponentialRampToValueAtTime(0.01, now + i * 0.15 + 0.35);
        
        osc.connect(gain);
        gain.connect(this.ctx!.destination);
        
        osc.start(now + i * 0.15);
        osc.stop(now + i * 0.15 + 0.35);
      });
    } catch (e) {
      console.warn("Audio failed to play", e);
    }
  }
}

// ==========================================
// HIGH-FIDELITY VECTOR SVG ROV CREST LOGO
// ==========================================
function RoVLogoCrest({ size = 80 }: { size?: number }) {
  return (
    <div 
      className="relative flex items-center justify-center pointer-events-none select-none"
      style={{ width: size, height: size }}
    >
      <div className="absolute inset-0 bg-red-600/30 rounded-full blur-xl animate-ping opacity-70"></div>
      <div className="absolute inset-[-8px] bg-gradient-to-r from-red-600 via-orange-600 to-amber-500 rounded-full blur-md opacity-80 animate-pulse"></div>
      
      <div className="absolute inset-0 border-2 border-cyan-400 rounded-full animate-spin [animation-duration:8s] opacity-40"></div>
      
      <svg
        viewBox="0 0 100 100"
        className="w-full h-full drop-shadow-[0_0_15px_rgba(239,68,68,0.9)] filter transform transition-transform"
      >
        <defs>
          <linearGradient id="goldGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ef4444" />
            <stop offset="50%" stopColor="#b91c1c" />
            <stop offset="100%" stopColor="#7f1d1d" />
          </linearGradient>
          <linearGradient id="accentGrad" x1="0" y1="0" x2="0" y2="1">
            <stop offset="0%" stopColor="#06b6d4" />
            <stop offset="100%" stopColor="#0891b2" />
          </linearGradient>
          <linearGradient id="gemGrad" x1="0" y1="0" x2="1" y2="1">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="100%" stopColor="#06b6d4" />
          </linearGradient>
        </defs>

        {/* Wings - Left */}
        <path
          d="M 50,25 C 40,15 20,20 12,38 C 8,47 12,60 25,65 C 30,55 38,48 50,45"
          fill="url(#goldGrad)"
          stroke="#000"
          strokeWidth="1.5"
        />
        
        {/* Wings - Right */}
        <path
          d="M 50,25 C 60,15 80,20 88,38 C 92,47 88,60 75,65 C 70,55 62,48 50,45"
          fill="url(#goldGrad)"
          stroke="#000"
          strokeWidth="1.5"
        />

        {/* Shield */}
        <path
          d="M 50,15 L 75,36 L 68,72 L 50,88 L 32,72 L 25,36 Z"
          fill="url(#goldGrad)"
          stroke="#000"
          strokeWidth="2"
        />
        
        {/* Shield Core */}
        <path
          d="M 50,21 L 69,38 L 63,68 L 50,81 L 37,68 L 31,38 Z"
          fill="#0c0a09"
          stroke="url(#accentGrad)"
          strokeWidth="2.5"
        />

        {/* Diamond Gem */}
        <polygon
          points="50,28 61,42 50,56 39,42"
          fill="url(#gemGrad)"
          stroke="#fff"
          strokeWidth="1"
        />

        {/* RoV Typography */}
        <text
          x="50"
          y="70"
          textAnchor="middle"
          fill="#ffffff"
          fontSize="15"
          fontWeight="900"
          fontFamily="Space Grotesk, Impact, sans-serif"
          letterSpacing="1.5"
          stroke="#000"
          strokeWidth="2"
        >
          RoV
        </text>
      </svg>
    </div>
  );
}

// ==========================================
// TYPES & SIMULATED APPLICANT STRUCTURE
// ==========================================
interface Applicant {
  id: number;
  studentId: string;
  fullname: string;
  inGameName: string;
  primaryRole: string;
  gameScore: number;
  createdAt: string;
}

interface ConsoleLog {
  text: string;
  type: 'info' | 'success' | 'sql' | 'error' | 'js';
  timestamp: string;
}

type TabType = 'sandbox' | 'explorer' | 'database';
type GameStage = 'portal' | 'login' | 'lobby' | 'loading' | 'playing' | 'gameover';

export default function App() {
  const [activeTab, setActiveTab] = useState<TabType>('sandbox');
  const [gameStage, setGameStage] = useState<GameStage>('portal');
  
  // Game metrics
  const [score, setScore] = useState<number>(0);
  const [timeLeft, setTimeLeft] = useState<number>(60);
  const [countdown, setCountdown] = useState<number | null>(null);
  const [isMuted, setIsMuted] = useState<boolean>(false);
  const [logoPosition, setLogoPosition] = useState<{ x: number; y: number }>({ x: 0.5, y: 0.5 });
  
  // Hand tracking statuses
  const [mediaPipeLoaded, setMediaPipeLoaded] = useState<boolean>(false);
  const [cameraReady, setCameraReady] = useState<boolean>(false);
  const [cameraError, setCameraError] = useState<string | null>(null);
  const [handDetected, setHandDetected] = useState<boolean>(false);

  // Login state (Inputs for simulated login.php)
  const [loginStudentId, setLoginStudentId] = useState<string>('');
  const [loginError, setLoginError] = useState<string>('');

  // Registration state (Inputs for simulated index.php)
  const [regStudentId, setRegStudentId] = useState<string>('');
  const [regFullname, setRegFullname] = useState<string>('');
  const [regInGameName, setRegInGameName] = useState<string>('');
  const [regPrimaryRole, setRegPrimaryRole] = useState<string>('');
  
  // Simulation entities
  const [activeApplicant, setActiveApplicant] = useState<Applicant | null>(null);
  const [applicants, setApplicants] = useState<Applicant[]>([]);
  const [phpConsole, setPhpConsole] = useState<ConsoleLog[]>([]);
  const [selectedFile, setSelectedFile] = useState<SourceFile>(sourceFiles[2]); // Default index.php
  const [copiedFile, setCopiedFile] = useState<string | null>(null);

  // Refs for tracking and real-time computation
  const videoRef = useRef<HTMLVideoElement | null>(null);
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const containerRef = useRef<HTMLDivElement | null>(null);
  const handsRef = useRef<any>(null);
  const cameraRefObj = useRef<any>(null);
  const activeStreamRef = useRef<MediaStream | null>(null);

  const logoPositionRef = useRef({ x: 0.5, y: 0.5 });
  const scoreRef = useRef<number>(0);

  // Sync mute state
  useEffect(() => {
    SoundEffects.isMuted = isMuted;
  }, [isMuted]);

  // Load simulated DB on mount & check MediaPipe
  useEffect(() => {
    const stored = localStorage.getItem('udru_rov_applicants_db');
    if (stored) {
      setApplicants(JSON.parse(stored));
    } else {
      const defaultApplicants: Applicant[] = [
        {
          id: 1,
          studentId: "6639010001",
          fullname: "อดิสร สว่างศรี",
          inGameName: "Adisor_UDRU",
          primaryRole: "Abyssal Dragon Lane (Carry)",
          gameScore: 32,
          createdAt: "07/07/2026, 14:24:00"
        },
        {
          id: 2,
          studentId: "6639010015",
          fullname: "นรินทร์ เจริญใจ",
          inGameName: "Narin_Slayer",
          primaryRole: "Dark Slayer Lane (Fighter)",
          gameScore: 21,
          createdAt: "07/07/2026, 15:45:00"
        },
        {
          id: 3,
          studentId: "6639010044",
          fullname: "เบญจวรรณ มีสุข",
          inGameName: "Benja_MidMage",
          primaryRole: "Middle Lane (Mage)",
          gameScore: 15,
          createdAt: "07/07/2026, 17:10:00"
        }
      ];
      localStorage.setItem('udru_rov_applicants_db', JSON.stringify(defaultApplicants));
      setApplicants(defaultApplicants);
    }

    addConsoleLog("🚀 ระบบวิเคราะห์พอร์ตโฟลิโอพัฒนาเว็บเซิร์ฟเวอร์เสมือนเริ่มทำงาน", 'info');
    addConsoleLog("👉 เปิดแท็บด้านบนเพื่อดูซอร์สโค้ด PHP/SQL และจำลองคำสั่งแบบบูรณาการ", 'info');

    // Periodically check if MediaPipe scripts from CDN are loaded and attached to window
    const checkMP = setInterval(() => {
      if ((window as any).Hands && (window as any).Camera) {
        setMediaPipeLoaded(true);
        clearInterval(checkMP);
      }
    }, 200);

    return () => {
      clearInterval(checkMP);
      stopCamera();
    };
  }, []);

  // Sync scoreRef with React state
  useEffect(() => {
    scoreRef.current = score;
  }, [score]);

  // Count down effect before actual gameplay start
  useEffect(() => {
    if (gameStage !== 'playing' || countdown === null) return;

    if (countdown > 0) {
      const timerId = setTimeout(() => {
        SoundEffects.playCountdown();
        setCountdown(countdown - 1);
      }, 1000);
      return () => clearTimeout(timerId);
    } else {
      setCountdown(null);
      setTimeLeft(60);
      relocateLogo();
    }
  }, [gameStage, countdown]);

  // 60-second Timer countdown effect
  useEffect(() => {
    if (gameStage !== 'playing' || countdown !== null) return;

    const timerId = setInterval(() => {
      setTimeLeft((prev) => {
        if (prev <= 1) {
          clearInterval(timerId);
          handleGameOver();
          return 0;
        }
        return prev - 1;
      });
    }, 1000);

    return () => clearInterval(timerId);
  }, [gameStage, countdown]);

  const addConsoleLog = (text: string, type: 'info' | 'success' | 'sql' | 'error' | 'js') => {
    const timestamp = new Date().toLocaleTimeString('th-TH');
    setPhpConsole((prev) => [...prev, { text, type, timestamp }].slice(-15)); // Keep last 15 logs
  };

  const handleGameOver = () => {
    setGameStage('gameover');
    SoundEffects.playGameOver();
    stopCamera();
    addConsoleLog("⏰ [SYSTEM] เวลาทดสอบการตรวจจับหมดลง 60 วินาทีเรียบร้อย", 'info');
    addConsoleLog(`📊 [SYSTEM] ได้รับคะแนนดิบ: ${scoreRef.current} คะแนน รอคำสั่ง Fetch API เพื่อเขียนข้อมูล`, 'js');
  };

  const relocateLogo = () => {
    const nextX = 0.15 + Math.random() * 0.70;
    const nextY = 0.15 + Math.random() * 0.70;
    const newPos = { x: nextX, y: nextY };
    logoPositionRef.current = newPos;
    setLogoPosition(newPos);
  };

  const handleLogoCaught = () => {
    SoundEffects.playCatch();
    setScore((prev) => prev + 1);
    relocateLogo();
  };

  // ==========================================
  // WEBCAM & HAND TRACKING SETUP
  // ==========================================
  const startTracking = async () => {
    SoundEffects.playClick();
    setCameraError(null);
    setGameStage('loading');
    setScore(0);
    setCountdown(3);
    setHandDetected(false);

    addConsoleLog("📸 [Camera] ร้องขอสิทธิ์ใช้งานโมดูลกล้องเว็บบอร์ดผ่าน Browser", 'info');

    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: {
          width: { ideal: 640 },
          height: { ideal: 480 },
          facingMode: "user"
        },
        audio: false
      });

      activeStreamRef.current = stream;
      if (videoRef.current) {
        videoRef.current.srcObject = stream;
      }

      // Setup MediaPipe Hands
      if (!handsRef.current) {
        const HandsClass = (window as any).Hands;
        const hands = new HandsClass({
          locateFile: (file: string) => `https://cdn.jsdelivr.net/npm/@mediapipe/hands/${file}`
        });

        hands.setOptions({
          maxNumHands: 1,
          modelComplexity: 1,
          minDetectionConfidence: 0.6,
          minTrackingConfidence: 0.6
        });

        hands.onResults(onResults);
        handsRef.current = hands;
      }

      // Setup Camera Utility
      if (videoRef.current) {
        const CameraClass = (window as any).Camera;
        const camera = new CameraClass(videoRef.current, {
          onFrame: async () => {
            if (handsRef.current && videoRef.current) {
              try {
                await handsRef.current.send({ image: videoRef.current });
              } catch (e) {}
            }
          },
          width: 640,
          height: 480
        });

        cameraRefObj.current = camera;
        await camera.start();
      }

      setCameraReady(true);
      setGameStage('playing');
      SoundEffects.playStart();
      addConsoleLog("🟢 [MediaPipe] ดึงโครงข่ายวิเคราะห์พิกัดฝ่ามือสำเร็จ ตัวกล้องสแตนด์บายเรียบร้อย!", 'success');

    } catch (err: any) {
      console.error("Camera setup failed:", err);
      let userMsg = "ไม่สามารถเชื่อมต่อกล้องได้ กรุณากดยอมรับสิทธิ์ใช้งานกล้องถ่ายรูป";
      if (err.name === "NotAllowedError" || err.name === "PermissionDeniedError") {
        userMsg = "เบราว์เซอร์ถูกปฏิเสธสิทธิ์เข้าใช้กล้องเว็บบอร์ด! กรุณากดยินยอมการเข้าใช้กล้องที่ที่อยู่แถบเว็บ";
      }
      setCameraError(userMsg);
      setGameStage('lobby');
      stopCamera();
      addConsoleLog(`🔴 [Camera Error] ${userMsg}`, 'error');
    }
  };

  const stopCamera = () => {
    if (cameraRefObj.current) {
      try { cameraRefObj.current.stop(); } catch (e) {}
      cameraRefObj.current = null;
    }
    if (activeStreamRef.current) {
      try { activeStreamRef.current.getTracks().forEach(track => track.stop()); } catch (e) {}
      activeStreamRef.current = null;
    }
    setCameraReady(false);
  };

  const onResults = (results: any) => {
    const video = videoRef.current;
    const canvas = canvasRef.current;
    if (!video || !canvas) return;

    const canvasCtx = canvas.getContext('2d');
    if (!canvasCtx) return;

    if (canvas.width !== video.clientWidth || canvas.height !== video.clientHeight) {
      canvas.width = video.clientWidth;
      canvas.height = video.clientHeight;
    }

    const cw = canvas.width;
    const ch = canvas.height;
    canvasCtx.clearRect(0, 0, cw, ch);

    if (results.multiHandLandmarks && results.multiHandLandmarks.length > 0) {
      setHandDetected(true);
      const landmarks = results.multiHandLandmarks[0];

      const drawConnectorsFn = (window as any).drawConnectors;
      const drawLandmarksFn = (window as any).drawLandmarks;
      const connections = (window as any).HAND_CONNECTIONS;

      if (drawConnectorsFn && drawLandmarksFn && connections) {
        // Draw neon connections and knuckles
        drawConnectorsFn(canvasCtx, landmarks, connections, { color: '#06b6d4', lineWidth: 4 });
        drawLandmarksFn(canvasCtx, landmarks, { color: '#ef4444', lineWidth: 1, radius: 4 });
      }

      // Index finger tip is point 8
      const indexFingerTip = landmarks[8];
      if (indexFingerTip) {
        const visualHandX = 1 - indexFingerTip.x;
        const visualHandY = indexFingerTip.y;

        // Custom pointer crosshair
        drawGamerCrosshair(canvasCtx, indexFingerTip.x, indexFingerTip.y, cw, ch);

        const isGamePlaying = logoPositionRef.current !== null;
        if (isGamePlaying) {
          const dx = visualHandX - logoPositionRef.current.x;
          const dy = visualHandY - logoPositionRef.current.y;
          const distance = Math.sqrt(dx * dx + dy * dy);

          if (distance < 0.08) {
            handleLogoCaught();
          }
        }
      }
    } else {
      setHandDetected(false);
    }
  };

  const drawGamerCrosshair = (ctx: CanvasRenderingContext2D, rawX: number, rawY: number, width: number, height: number) => {
    const px = rawX * width;
    const py = rawY * height;

    ctx.save();
    ctx.shadowBlur = 10;
    ctx.shadowColor = '#06b6d4';

    // Circle target
    ctx.beginPath();
    ctx.arc(px, py, 18, 0, Math.PI * 2);
    ctx.strokeStyle = '#22c55e';
    ctx.lineWidth = 3;
    ctx.stroke();

    // Red core dot
    ctx.beginPath();
    ctx.arc(px, py, 4, 0, Math.PI * 2);
    ctx.fillStyle = '#ef4444';
    ctx.fill();

    ctx.restore();
  };

  // ==========================================
  // SIMULATED FULL-STACK OPERATIONS (PHP/SQL)
  // ==========================================
  
  // 1. simulated submission of index.php
  const handleSimulatedRegister = (e: FormEvent) => {
    e.preventDefault();
    if (!regStudentId || !regFullname || !regInGameName || !regPrimaryRole) return;

    SoundEffects.playClick();
    
    addConsoleLog(`📥 [PHP Server] รัน POST Request ไปยัง index.php...`, 'info');
    addConsoleLog(`⚙️ [PHP Server] โหลดไฟล์ตั้งค่า db.php เชื่อมต่อ MySQL database ด้วย PDO...`, 'info');
    addConsoleLog(`🔗 [PDO Connection] เชื่อมต่อไปยังเซิร์ฟเวอร์ Localhost ยืนยันสำเร็จ`, 'success');
    
    // Check if duplicate student_id
    const existing = applicants.find(a => a.studentId === regStudentId);

    if (existing) {
      addConsoleLog(`🔍 [SQL Query] SELECT id FROM rov_applicants WHERE student_id = '${regStudentId}'`, 'sql');
      addConsoleLog(`⚡ [SQL Result] ตรวจพบข้อมูลเดิมสมัครซ้ำ! เชื่อมโยงรหัส ID ${existing.id} อัตโนมัติ`, 'info');
      addConsoleLog(`💾 [PHP Session] บันทึกรหัส $_SESSION['applicant_id'] = ${existing.id}`, 'success');
      addConsoleLog(`🔀 [PHP Redirect] ย้ายปลายทางจาก index.php -> game.html`, 'info');
      
      setActiveApplicant(existing);
      
      setTimeout(() => {
        startTracking();
      }, 800);
    } else {
      const newId = applicants.length > 0 ? Math.max(...applicants.map(a => a.id)) + 1 : 1;
      const newApplicant: Applicant = {
        id: newId,
        studentId: regStudentId,
        fullname: regFullname,
        inGameName: regInGameName,
        primaryRole: regPrimaryRole,
        gameScore: 0,
        createdAt: new Date().toLocaleString('th-TH')
      };

      addConsoleLog(`🔍 [SQL Query] SELECT id FROM rov_applicants WHERE student_id = '${regStudentId}' LIMIT 1`, 'sql');
      addConsoleLog(`⚡ [SQL Result] คืนค่า 0 แถว (ไม่พบประวัติซ้ำซ้อน) พร้อมดำเนินการบันทึกตัวตนนักใหม่`, 'info');
      addConsoleLog(`📝 [SQL Query] INSERT INTO rov_applicants (student_id, fullname, in_game_name, primary_role, game_score) VALUES ('${regStudentId}', '${regFullname}', '${regInGameName}', '${regPrimaryRole}', 0)`, 'sql');
      
      const updated = [...applicants, newApplicant];
      setApplicants(updated);
      localStorage.setItem('udru_rov_applicants_db', JSON.stringify(updated));

      addConsoleLog(`💾 [PHP Session] ตั้งค่า $_SESSION['applicant_id'] = ${newId} (สมัครคนใหม่)`, 'success');
      addConsoleLog(`🔀 [PHP Redirect] ย้ายปลายทางจาก index.php -> game.html เพื่อเริ่มทักษะสอบ`, 'info');

      setActiveApplicant(newApplicant);
      
      setTimeout(() => {
        startTracking();
      }, 800);
    }
  };

  // 1.5. Simulated login of login.php
  const handleSimulatedLogin = (e: FormEvent) => {
    e.preventDefault();
    if (!loginStudentId) return;

    SoundEffects.playClick();
    setLoginError('');
    
    addConsoleLog(`📥 [PHP Server] รัน POST Request ไปยัง login.php...`, 'info');
    addConsoleLog(`⚙️ [PHP Server] โหลดไฟล์ตั้งค่า db.php เชื่อมต่อ MySQL database ด้วย PDO...`, 'info');
    addConsoleLog(`🔗 [PDO Connection] เชื่อมต่อไปยังเซิร์ฟเวอร์ Localhost ยืนยันสำเร็จ`, 'success');
    
    const existing = applicants.find(a => a.studentId === loginStudentId);

    if (existing) {
      addConsoleLog(`🔍 [SQL Query] SELECT id, fullname FROM rov_applicants WHERE student_id = '${loginStudentId}' LIMIT 1`, 'sql');
      addConsoleLog(`⚡ [SQL Result] คืนค่า 1 แถว (พบประวัติคัดตัวเดิม) • รหัสผู้สมัคร ID ${existing.id} (${existing.fullname})`, 'success');
      addConsoleLog(`💾 [PHP Session] ตั้งค่า $_SESSION['applicant_id'] = ${existing.id} และ $_SESSION['student_id'] = '${loginStudentId}'`, 'success');
      addConsoleLog(`🔀 [PHP Redirect] ย้ายปลายทางจาก login.php -> game.html เพื่อเริ่มทักษะสอบ`, 'info');
      
      setActiveApplicant(existing);
      
      setTimeout(() => {
        startTracking();
      }, 800);
    } else {
      addConsoleLog(`🔍 [SQL Query] SELECT id, fullname FROM rov_applicants WHERE student_id = '${loginStudentId}' LIMIT 1`, 'sql');
      addConsoleLog(`⚠️ [SQL Result] คืนค่า 0 แถว • ไม่พบประวัติผู้ใช้รหัส '${loginStudentId}' ใน MySQL!`, 'error');
      setLoginError('ไม่พบรหัสนักศึกษานี้ในระบบ! กรุณาตรวจสอบรหัส หรือกดสมัครสมาชิกผู้คัดตัวรายใหม่');
    }
  };

  // 2. Simulated submission of score update (AJAX update_score.php)
  const submitSimulatedScore = () => {
    if (!activeApplicant) return;

    SoundEffects.playClick();
    addConsoleLog(`📡 [JavaScript] Fetching 'update_score.php' ด้วยข้อมูล POST: { score: ${score} }`, 'js');
    addConsoleLog(`⚙️ [PHP API] ประมวลผลคำขอร้องจาก update_score.php...`, 'info');
    
    const currentBest = activeApplicant.gameScore;
    const finalBest = Math.max(currentBest, score);

    addConsoleLog(`💾 [PHP Session] ตรวจพบตัวเซสชันตรวจสอบสิทธิ์ผู้ใช้ applicant_id: ${activeApplicant.id}`, 'success');
    addConsoleLog(`🔍 [SQL Query] SELECT game_score FROM rov_applicants WHERE id = ${activeApplicant.id}`, 'sql');
    addConsoleLog(`⚡ [SQL Result] คะแนนเดิมที่ดีที่สุด: ${currentBest} PTS • คะแนนรอบการทดสอบใหม่: ${score} PTS`, 'info');
    addConsoleLog(`📝 [SQL Query] UPDATE rov_applicants SET game_score = ${finalBest} WHERE id = ${activeApplicant.id}`, 'sql');

    // Update state
    const updated = applicants.map(a => {
      if (a.id === activeApplicant.id) {
        return { ...a, gameScore: finalBest };
      }
      return a;
    });

    setApplicants(updated);
    localStorage.setItem('udru_rov_applicants_db', JSON.stringify(updated));
    setActiveApplicant({ ...activeApplicant, gameScore: finalBest });

    addConsoleLog(`✅ [PHP API Response] ส่งค่า JSON ตอบกลับสำเร็จ: { success: true, message: "บันทึกคะแนนสะสมความไวลงสู่ฐานข้อมูล UDRU สำเร็จ!", score: ${finalBest} }`, 'success');

    // Return to portal
    setTimeout(() => {
      setGameStage('portal');
      setRegStudentId('');
      setRegFullname('');
      setRegInGameName('');
      setRegPrimaryRole('');
      setLoginStudentId('');
      setActiveApplicant(null);
    }, 1500);
  };

  // Clear Database Simulation
  const handleClearDatabase = () => {
    SoundEffects.playClick();
    if (confirm("คุณแน่ใจหรือไม่ว่าต้องการรีเซ็ตล้างตารางข้อมูลในระบบจำลองจำลองเพื่อทดสอบคัดเลือกใหม่ทั้งหมด?")) {
      localStorage.removeItem('udru_rov_applicants_db');
      setApplicants([]);
      addConsoleLog("🧹 [SQL Execute] TRUNCATE TABLE `rov_applicants`; ล้างตารางข้อมูลว่างเปล่าเรียบร้อย", 'sql');
    }
  };

  // Copy code utility
  const handleCopyCode = (text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedFile(selectedFile.name);
    SoundEffects.playClick();
    setTimeout(() => setCopiedFile(null), 2000);
  };

  // Download file utility
  const handleDownloadFile = (file: SourceFile) => {
    SoundEffects.playClick();
    const blob = new Blob([file.content], { type: 'text/plain;charset=utf-8' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = file.name;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  // Rank calculator for database list
  const getSimulatedRank = (pts: number) => {
    if (pts <= 5) return { name: 'Bronze', color: 'bg-amber-950/40 text-amber-500 border-amber-800/40' };
    if (pts <= 15) return { name: 'Silver', color: 'bg-slate-900/40 text-slate-400 border-slate-700/40' };
    if (pts <= 25) return { name: 'Gold', color: 'bg-yellow-950/40 text-yellow-500 border-yellow-800/40' };
    if (pts <= 35) return { name: 'Platinum', color: 'bg-emerald-950/40 text-emerald-400 border-emerald-800/40' };
    if (pts <= 45) return { name: 'Diamond', color: 'bg-sky-950/40 text-sky-400 border-sky-800/40' };
    return { name: 'Conqueror', color: 'bg-red-950/40 text-red-500 border-red-800/40 animate-pulse' };
  };

  return (
    <div className="min-h-screen bg-[#06060c] bg-radial-[circle_at_center,rgba(8,47,73,0.3)_0%,rgba(6,6,12,1)_100%] text-neutral-100 font-sans p-3 md:p-6 flex flex-col justify-between relative">
      
      {/* Background Decorative Grid */}
      <div className="absolute inset-0 opacity-10 pointer-events-none -z-10" style={{ backgroundImage: "linear-gradient(#38bdf8 1px, transparent 1px), linear-gradient(90deg, #38bdf8 1px, transparent 1px)", backgroundSize: "45px 45px" }}></div>

      {/* ================= TOP BRAND HUB HEADER ================= */}
      <header className="w-full max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between border-b border-cyan-950 pb-4 mb-6 gap-4">
        <div className="flex items-center gap-4">
          <div className="w-12 h-12 bg-cyan-500 rounded-lg flex items-center justify-center transform rotate-45 shadow-[0_0_20px_rgba(6,182,212,0.6)] border border-white/20">
            <span className="transform -rotate-45 font-black text-slate-950 text-2xl font-mono">U</span>
          </div>
          <div className="text-center md:text-left">
            <div className="flex items-center justify-center md:justify-start gap-2.5">
              <h1 className="text-xl md:text-2xl font-black tracking-tight uppercase italic text-cyan-400 font-sans">
                UDRU E-SPORTS
              </h1>
              <span className="px-2 py-0.5 bg-cyan-950 text-cyan-400 border border-cyan-800 text-[9px] font-mono rounded tracking-widest uppercase">LAB_CENTER</span>
            </div>
            <p className="text-[10px] text-slate-400 tracking-wider font-mono">
              COMPUTER VISION • FULL-STACK ATHLETE REGISTRATION PLATFORM
            </p>
          </div>
        </div>

        {/* Global Sound & MediaPipe Status indicators */}
        <div className="flex items-center gap-3">
          <button 
            onClick={() => {
              SoundEffects.playClick();
              setIsMuted(!isMuted);
            }} 
            className="p-2.5 rounded bg-slate-900 border border-slate-800 hover:border-cyan-500/50 hover:bg-slate-800 transition-all text-slate-400 hover:text-white flex items-center justify-center cursor-pointer"
            title={isMuted ? "เปิดเสียงระฆังเอฟเฟกต์" : "ปิดเสียงชั่วคราว"}
          >
            {isMuted ? <VolumeX className="w-4 h-4 text-red-500" /> : <Volume2 className="w-4 h-4 text-emerald-400" />}
          </button>
          
          <div className="flex items-center gap-2.5 px-3.5 py-2 rounded bg-slate-900 border border-slate-800 font-mono text-[10px] font-bold text-slate-400 shadow-inner">
            <span className={`h-2 w-2 rounded-full ${mediaPipeLoaded ? 'bg-emerald-500 animate-pulse shadow-[0_0_8px_#10b981]' : 'bg-red-500'}`}></span>
            <span>{mediaPipeLoaded ? 'AI TRACKING READY' : 'LOADING AI MODELS...'}</span>
          </div>
        </div>
      </header>

      {/* ================= MAIN DISPLAY STAGE ================= */}
      <main className="w-full max-w-6xl mx-auto flex-grow grid grid-cols-1 lg:grid-cols-12 gap-6 items-start relative z-10">
        
        {/* LEFT/MAIN DYNAMIC COLUMN */}
        <div className="lg:col-span-8 w-full space-y-6">
          
          {/* ================= PLAYING / LOBBY PORTAL ================= */}
          <div className="space-y-6">
              
              {/* STAGE PORTAL: CLUB PORTAL LANDING PAGE */}
              {gameStage === 'portal' && (
                <div className="bg-slate-950/70 border-2 border-cyan-500/30 p-6 md:p-8 rounded-xl shadow-2xl relative backdrop-blur-md space-y-6">
                  {/* Glowing corners */}
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-cyan-400 rounded-tl-lg"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-cyan-400 rounded-tr-lg"></div>
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-cyan-400 rounded-bl-lg"></div>
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-cyan-400 rounded-br-lg"></div>

                  <div className="text-center space-y-3">
                    <span className="px-3 py-1 bg-cyan-950/60 text-cyan-400 border border-cyan-800 text-xs font-mono rounded-full tracking-wider uppercase inline-block animate-pulse">// UDRU E-SPORTS CLUB PORTAL</span>
                    <h2 className="text-3xl md:text-4xl font-black uppercase text-transparent bg-clip-text bg-gradient-to-r from-white via-slate-100 to-cyan-400 tracking-tight italic">
                      ชมรมอีสปอร์ต มหาวิทยาลัยราชภัฏอุดรธานี
                    </h2>
                    <p className="text-xs text-slate-400 max-w-xl mx-auto leading-relaxed">
                      ยินดีต้อนรับสู่ศูนย์กลางการคัดเลือกนักกีฬาของชมรมอีสปอร์ต มรภ.อุดรธานี เรามุ่งมั่นพัฒนาทักษะ เสริมสร้างความร่วมมือแบบทีม และผลักดันศักยภาพนักกีฬาสู่ความเป็นมืออาชีพในระดับภูมิภาคและระดับประเทศ
                    </p>
                  </div>

                  {/* Club Stats / Achievements Showcase */}
                  <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
                    <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-lg flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-cyan-950/60 border border-cyan-800 flex items-center justify-center shrink-0">
                        <Trophy className="w-5 h-5 text-cyan-400" />
                      </div>
                      <div>
                        <div className="text-sm font-black text-white">3 เหรียญทอง</div>
                        <div className="text-[10px] text-slate-500">Rajabhat Games ล่าสุด</div>
                      </div>
                    </div>

                    <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-lg flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-emerald-950/60 border border-emerald-800 flex items-center justify-center shrink-0">
                        <Users className="w-5 h-5 text-emerald-400" />
                      </div>
                      <div>
                        <div className="text-sm font-black text-white">150+ สมาชิก</div>
                        <div className="text-[10px] text-slate-500">ร่วมสังคมและคอมมูนิตี้</div>
                      </div>
                    </div>

                    <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-lg flex items-center gap-3">
                      <div className="w-10 h-10 rounded bg-amber-950/60 border border-amber-800 flex items-center justify-center shrink-0">
                        <Sparkles className="w-5 h-5 text-amber-400" />
                      </div>
                      <div>
                        <div className="text-sm font-black text-white">AI Hand Track</div>
                        <div className="text-[10px] text-slate-500">ตรวจจับประมวลผล</div>
                      </div>
                    </div>
                  </div>

                  {/* Info banner about selection test */}
                  <div className="bg-slate-900/20 border border-slate-900 p-5 rounded-lg space-y-2">
                    <h3 className="text-xs font-bold text-cyan-400 tracking-wider uppercase flex items-center gap-1.5 font-mono">
                      <Gamepad2 className="w-4 h-4 text-cyan-400" /> รายละเอียดการคัดตัวทีมแข่งขัน RoV
                    </h3>
                    <p className="text-xs text-slate-400 leading-relaxed">
                      การคัดเลือกนักกีฬาชุดหลักใช้การประเมินความเร็วประสาทสัมผัส (Reflex & Motor Skill) โดยตรวจจับท่าทางฝ่ามือของนักศึกษาด้วยกล้องเว็บแคมผ่านระบบ AI สถิติคะแนนทั้งหมดของจะถูกบันทึกเข้าระบบเพื่อใช้ประกอบการพิจารณาตำแหน่งตัวจริง!
                    </p>
                  </div>

                  {/* Actions to proceed */}
                  <div className="pt-2 max-w-md mx-auto space-y-4">
                    <button
                      onClick={() => {
                        SoundEffects.playClick();
                        setGameStage('login');
                        addConsoleLog(`📂 [PHP Route] ผู้ใช้เปลี่ยนหน้าไปยังหน้าเข้าสู่ระบบ (login.php)`, 'info');
                      }}
                      className="w-full py-4 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic tracking-widest rounded transform -skew-x-12 transition-all shadow-[0_5px_15px_rgba(6,182,212,0.3)] hover:scale-[1.01] cursor-pointer flex items-center justify-center gap-2"
                    >
                      <LogIn className="w-4 h-4 shrink-0 transform skew-x-12" />
                      <span className="inline-block transform skew-x-12 font-bold text-xs">
                        เข้าสู่ระบบด้วยรหัสเดิม (LOGIN)
                      </span>
                    </button>

                    <button
                      onClick={() => {
                        SoundEffects.playClick();
                        setGameStage('lobby');
                        addConsoleLog(`📂 [PHP Route] ผู้ใช้เปลี่ยนหน้าไปยังหน้าสมัครใหม่ (register.php)`, 'info');
                      }}
                      className="w-full py-4 border border-cyan-500 text-cyan-400 hover:bg-cyan-500/10 font-black uppercase italic tracking-widest rounded transform -skew-x-12 transition-all hover:scale-[1.01] cursor-pointer flex items-center justify-center gap-2"
                    >
                      <UserPlus className="w-4 h-4 shrink-0 transform skew-x-12" />
                      <span className="inline-block transform skew-x-12 font-bold text-xs">
                        ลงทะเบียนผู้สมัครรายใหม่ (REGISTER)
                      </span>
                    </button>
                  </div>
                </div>
              )}

              {/* STAGE LOGIN: EXISTING APPLICANT LOGIN SCREEN */}
              {gameStage === 'login' && (
                <div className="bg-slate-950/70 border-2 border-cyan-500/30 p-6 md:p-8 rounded-xl shadow-2xl relative backdrop-blur-md">
                  {/* Glowing corners */}
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-cyan-400 rounded-tl-lg"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-cyan-400 rounded-tr-lg"></div>
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-cyan-400 rounded-bl-lg"></div>
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-cyan-400 rounded-br-lg"></div>

                  <div className="flex items-center justify-between border-b border-slate-900 pb-4 mb-6">
                    <button
                      onClick={() => {
                        SoundEffects.playClick();
                        setGameStage('portal');
                      }}
                      className="px-3 py-1.5 border border-slate-800 hover:bg-slate-900 text-slate-400 hover:text-white rounded text-[10px] font-bold font-mono uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft className="w-3 h-3" /> BACK PORTAL
                    </button>
                    <span className="text-[10px] font-mono text-cyan-400 font-bold tracking-widest uppercase">// LOGIN_FLOW</span>
                  </div>

                  <div className="text-center mb-6">
                    <span className="text-cyan-400 text-xs tracking-[0.2em] font-mono block mb-1">SIMULATION OF LOGIN.PHP</span>
                    <h2 className="text-2xl md:text-3xl font-black uppercase text-white tracking-tight italic">เข้าสู่ระบบผู้สมัครคัดเลือก</h2>
                    <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                      กรอกรหัสนักศึกษาเดิมที่คุณลงทะเบียนไว้แล้ว เพื่อดึงประวัติมาสอบปฏิกิริยาและเก็บคะแนนสะสมต่อเนื่อง
                    </p>
                  </div>

                  {loginError && (
                    <div className="mb-5 p-3 rounded bg-red-950/40 border border-red-500/30 text-red-300 text-xs text-center max-w-md mx-auto">
                      ⚠️ {loginError}
                    </div>
                  )}

                  <form onSubmit={handleSimulatedLogin} className="space-y-5 max-w-md mx-auto">
                    <div>
                      <label className="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1.5">
                        รหัสนักศึกษา (Student ID)
                      </label>
                      <input 
                        type="text" 
                        required
                        value={loginStudentId}
                        onChange={(e) => setLoginStudentId(e.target.value)}
                        placeholder="ระบุรหัสนักศึกษา (เช่น 6639010012)" 
                        className="w-full px-4 py-2.5 rounded bg-slate-900 border border-slate-800 text-slate-200 outline-none text-sm transition-all focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40 font-mono"
                      />
                    </div>

                    <div className="pt-2">
                      <button 
                        type="submit" 
                        className="w-full py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic tracking-wider rounded transform -skew-x-12 transition-all shadow-[0_10px_20px_rgba(6,182,212,0.3)] hover:scale-[1.01] cursor-pointer"
                      >
                        <span className="inline-block transform skew-x-12 font-bold text-xs flex items-center justify-center gap-2">
                          เข้าสู่ระบบดึงข้อมูล &amp; สอบต่อ <ArrowRight className="w-4 h-4" />
                        </span>
                      </button>
                    </div>
                  </form>

                  <div className="mt-6 text-center text-xs text-slate-500">
                    ยังไม่มีประวัติในฐานข้อมูลผู้ลงสมัครสมัครคัดเลือก?{' '}
                    <button
                      onClick={() => {
                        SoundEffects.playClick();
                        setGameStage('lobby');
                      }}
                      className="text-cyan-400 hover:underline font-bold"
                    >
                      สมัครคัดเลือกใหม่ที่นี่
                    </button>
                  </div>
                </div>
              )}

              {/* STAGE A: REGISTRATION LOBBY (index.php Simulation) */}
              {gameStage === 'lobby' && (
                <div className="bg-slate-950/70 border-2 border-cyan-500/30 p-6 md:p-8 rounded-xl shadow-2xl relative backdrop-blur-md">
                  {/* Glowing corners */}
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-cyan-400 rounded-tl-lg"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-cyan-400 rounded-tr-lg"></div>
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-cyan-400 rounded-bl-lg"></div>
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-cyan-400 rounded-br-lg"></div>

                  <div className="flex items-center justify-between border-b border-slate-900 pb-4 mb-6">
                    <button
                      onClick={() => {
                        SoundEffects.playClick();
                        setGameStage('portal');
                      }}
                      className="px-3 py-1.5 border border-slate-800 hover:bg-slate-900 text-slate-400 hover:text-white rounded text-[10px] font-bold font-mono uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                    >
                      <ArrowLeft className="w-3 h-3" /> BACK PORTAL
                    </button>
                    <span className="text-[10px] font-mono text-cyan-400 font-bold tracking-widest uppercase">// REGISTER_FLOW</span>
                  </div>

                  <div className="text-center mb-6">
                    <span className="text-cyan-400 text-xs tracking-[0.2em] font-mono block mb-1">SIMULATION OF REGISTER.PHP</span>
                    <h2 className="text-2xl md:text-3xl font-black uppercase text-white tracking-tight italic">ลงชื่อเข้าสมัครคัดตัวนักกีฬา</h2>
                    <p className="text-xs text-slate-400 mt-1 max-w-md mx-auto">
                      กรอกข้อมูลนักศึกษาจริงของคุณเพื่อบันทึกลงสู่ Virtual MySQL Database ระบบจะจำลองกระบวนการเชื่อมต่อ PDO และพาส่งต่อไปยังตัวทดสอบกล้องทันที
                    </p>
                  </div>

                  <form onSubmit={handleSimulatedRegister} className="space-y-4 max-w-md mx-auto">
                    <div>
                      <label className="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1.5">
                        รหัสนักศึกษา (Student ID)
                      </label>
                      <input 
                        type="text" 
                        required
                        pattern="[0-9\-]+"
                        value={regStudentId}
                        onChange={(e) => setRegStudentId(e.target.value)}
                        placeholder="กรอกรหัสคอมพิวเตอร์ (เช่น 6639010012)" 
                        className="w-full px-4 py-2.5 rounded bg-slate-900 border border-slate-800 text-slate-200 outline-none text-sm transition-all focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40 font-mono"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1.5">
                        ชื่อ - นามสกุลจริง (Full Name)
                      </label>
                      <input 
                        type="text" 
                        required
                        value={regFullname}
                        onChange={(e) => setRegFullname(e.target.value)}
                        placeholder="นายศักดิ์สิทธิ์ เรียนเก่ง" 
                        className="w-full px-4 py-2.5 rounded bg-slate-900 border border-slate-800 text-slate-200 outline-none text-sm transition-all focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1.5">
                        ชื่อเรียกในเกม RoV (In-Game Name)
                      </label>
                      <input 
                        type="text" 
                        required
                        value={regInGameName}
                        onChange={(e) => setRegInGameName(e.target.value)}
                        placeholder="UDRU_FighterCarry" 
                        className="w-full px-4 py-2.5 rounded bg-slate-900 border border-slate-800 text-slate-200 outline-none text-sm transition-all focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40"
                      />
                    </div>

                    <div>
                      <label className="block text-[10px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1.5">
                        เลนหรือตำแหน่งหลัก (Primary Role)
                      </label>
                      <select 
                        required
                        value={regPrimaryRole}
                        onChange={(e) => setRegPrimaryRole(e.target.value)}
                        className="w-full px-4 py-2.5 rounded bg-slate-900 border border-slate-800 text-slate-200 outline-none text-sm transition-all focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500/40 cursor-pointer"
                      >
                        <option value="">-- เลือกเลนถนัดในแผนที่ --</option>
                        <option value="Abyssal Dragon Lane (Carry)">Abyssal Dragon Lane (Carry) - เลนมังกรทำดาเมจ</option>
                        <option value="Dark Slayer Lane (Fighter)">Dark Slayer Lane (Fighter) - ออฟเลนประจันหน้า</option>
                        <option value="Middle Lane (Mage)">Middle Lane (Mage) - คุมเลนกลางเวทมนตร์</option>
                        <option value="Jungle (Assassin)">Jungle (Assassin) - ฟาร์มป่าล่าสังหาร</option>
                        <option value="Roaming (Support/Tank)">Roaming (Support/Tank) - ซัพพอร์ตเดินแก๊งก์คุ้มกัน</option>
                      </select>
                    </div>

                    <div className="pt-2">
                      <button 
                        type="submit" 
                        className="w-full py-3.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 font-black uppercase italic tracking-wider rounded transform -skew-x-12 transition-all shadow-[0_10px_20px_rgba(6,182,212,0.3)] hover:scale-[1.01] cursor-pointer"
                      >
                        <span className="inline-block transform skew-x-12 font-bold text-xs flex items-center justify-center gap-2">
                          บันทึกข้อมูลเข้าสู่เซิร์ฟเวอร์จำลอง &amp; เข้าเกมคัดเลือก <ArrowRight className="w-4 h-4" />
                        </span>
                      </button>
                    </div>
                  </form>
                </div>
              )}

              {/* STAGE B: LOADING SYSTEM/WEBCAM */}
              {gameStage === 'loading' && (
                <div className="bg-slate-950 border border-slate-800 rounded-xl p-12 text-center flex flex-col items-center justify-center space-y-5 min-h-[400px]">
                  <div className="relative w-16 h-16 flex items-center justify-center bg-cyan-950 rounded-full border border-cyan-500/50 animate-pulse">
                    <Camera className="w-7 h-7 text-cyan-400 animate-spin [animation-duration:4s]" />
                    <div className="absolute inset-0 rounded-full border-2 border-dashed border-red-500 animate-spin [animation-duration:12s]"></div>
                  </div>
                  <div>
                    <h3 className="text-lg font-black tracking-widest text-cyan-400">CONNECTING TO MEDIAPIPE AI</h3>
                    <p className="text-xs text-slate-400 font-mono mt-1">
                      กำลังเปิดฟีดกล้องเว็บบอร์ดและโหลดโมเดลสแกนนิ้วมือกรุณายอมรับสิทธิ์ใช้งานกล้อง...
                    </p>
                  </div>
                  <div className="w-32 h-1.5 bg-slate-900 rounded-full overflow-hidden border border-slate-800">
                    <div className="h-full bg-gradient-to-r from-cyan-500 to-emerald-500 animate-[progress_2s_ease-out_infinite] w-2/3"></div>
                  </div>
                </div>
              )}

              {/* STAGE C: ACTIVE GAMEPLAY */}
              {gameStage === 'playing' && (
                <div className="space-y-4">
                  {/* Mini Sleek HUD */}
                  <div className="flex items-center justify-between p-3.5 bg-slate-950 border border-slate-900 rounded-xl shadow-lg font-mono">
                    <div className="flex items-center gap-2.5">
                      <div className="w-8 h-8 rounded bg-cyan-950 flex items-center justify-center border border-cyan-800">
                        <Trophy className="w-4 h-4 text-cyan-400" />
                      </div>
                      <div>
                        <span className="text-[8px] text-slate-500 block">SCORE</span>
                        <span className="text-lg font-black text-cyan-400">{score} <span className="text-[10px] text-slate-500">PTS</span></span>
                      </div>
                    </div>

                    <div className="flex items-center gap-2">
                      <span className={`h-2.5 w-2.5 rounded-full ${handDetected ? 'bg-emerald-500 shadow-[0_0_8px_#10b981]' : 'bg-red-500 animate-pulse'}`}></span>
                      <span className="text-[10px] text-slate-400">
                        {handDetected ? 'ตรวจจับฝ่ามือ OK' : 'กรุณาชูฝ่ามือขึ้นหน้ากล้อง'}
                      </span>
                    </div>

                    <div className="flex items-center gap-2.5 text-right">
                      <div>
                        <span className="text-[8px] text-slate-500 block">TIME REMAINING</span>
                        <span className={`text-lg font-black ${timeLeft <= 10 ? 'text-red-500 animate-pulse' : 'text-red-400'}`}>
                          00:{timeLeft < 10 ? '0' + timeLeft : timeLeft}
                        </span>
                      </div>
                      <div className="w-8 h-8 rounded bg-red-950 flex items-center justify-center border border-red-900">
                        <Timer className={`w-4 h-4 text-red-500 ${timeLeft <= 10 ? 'animate-bounce' : ''}`} />
                      </div>
                    </div>
                  </div>

                  {/* Camera Canvas Container */}
                  <div 
                    ref={containerRef}
                    className="w-full aspect-[4/3] bg-slate-950 rounded-xl border-4 border-slate-900 relative overflow-hidden shadow-2xl group"
                  >
                    {/* Retro Scanline Layer */}
                    <div className="absolute inset-0 bg-gradient-to-b from-transparent 50%, rgba(0,0,0,0.3) 50% pointer-events-none z-15 bg-[size:100%_4px]"></div>
                    
                    {/* Corners */}
                    <div className="absolute top-0 left-0 w-8 h-8 border-t-4 border-l-4 border-cyan-500 rounded-tl-lg z-20"></div>
                    <div className="absolute top-0 right-0 w-8 h-8 border-t-4 border-r-4 border-cyan-500 rounded-tr-lg z-20"></div>
                    <div className="absolute bottom-0 left-0 w-8 h-8 border-b-4 border-l-4 border-cyan-500 rounded-bl-lg z-20"></div>
                    <div className="absolute bottom-0 right-0 w-8 h-8 border-b-4 border-r-4 border-cyan-500 rounded-br-lg z-20"></div>

                    {/* Flipped Camera View */}
                    <video ref={videoRef} className="absolute inset-0 w-full h-full object-cover scale-x-[-1]" playsInline muted />
                    <canvas ref={canvasRef} className="absolute inset-0 w-full h-full object-cover scale-x-[-1] z-10" />

                    {/* Hover instructions if hand not seen */}
                    {!handDetected && countdown === null && (
                      <div className="absolute top-12 left-1/2 transform -translate-x-1/2 px-4 py-2 rounded-full bg-black/80 border border-cyan-500/40 text-cyan-400 text-xs font-bold font-mono tracking-wider animate-bounce z-25 backdrop-blur-md flex items-center gap-1.5 shadow-lg">
                        <Sparkles className="w-4 h-4 text-yellow-400" /> ชูฝ่ามือขึ้นจอเพื่อให้ AI หาจุดนิ้วชี้เล็งเป้า
                      </div>
                    )}

                    {/* Pre-game Countdown Overlay */}
                    {countdown !== null && (
                      <div className="absolute inset-0 bg-slate-950/90 flex flex-col items-center justify-center z-30 backdrop-blur-md select-none">
                        <p className="text-[10px] font-mono tracking-widest text-cyan-400 uppercase animate-pulse mb-1">SYNCHRONIZING COMPUTER VISION CAMERA</p>
                        <h2 className="text-8xl font-black text-transparent bg-clip-text bg-gradient-to-b from-cyan-300 to-cyan-600 font-mono animate-ping">
                          {countdown === 0 ? "GO!" : countdown}
                        </h2>
                        <p className="text-xs text-slate-500 mt-4 max-w-xs text-center">
                          นิ้วชี้ของคุณจะทำหน้าที่แทนพอยเตอร์เมาส์ เล็งทับเป้าหมายสีแดงให้โดนเพื่อทำสถิติต่อเนื่อง!
                        </p>
                      </div>
                    )}

                    {/* Spatially Floating RoV Crest Target */}
                    {countdown === null && (
                      <div 
                        className="absolute pointer-events-none z-20 transition-all duration-300 ease-out"
                        style={{
                          left: `${logoPosition.x * 100}%`,
                          top: `${logoPosition.y * 100}%`,
                          transform: 'translate(-50%, -50%)'
                        }}
                      >
                        <RoVLogoCrest size={76} />
                      </div>
                    )}
                  </div>

                  {/* Gameplay controls */}
                  <div className="flex justify-between items-center px-1">
                    <button
                      onClick={() => { SoundEffects.playClick(); stopCamera(); setGameStage('portal'); }}
                      className="px-4 py-2 border border-slate-800 hover:bg-slate-900 text-slate-400 hover:text-white rounded text-xs font-black uppercase italic tracking-wider flex items-center gap-1.5 cursor-pointer"
                    >
                      <RotateCcw className="w-3.5 h-3.5" /> ยกเลิกการสอบ (EXIT)
                    </button>
                    <span className="text-[10px] text-slate-500 font-mono">
                      *จำลองสัญญาณกล้องเว็บแคนวาสภายใน AI-Sandbox ปราศจากหน่วงรันไทม์
                    </span>
                  </div>
                </div>
              )}

              {/* STAGE D: GAME OVER DISPLAY (Simulated AJAX update_score.php Screen) */}
              {gameStage === 'gameover' && activeApplicant && (
                <div className="bg-slate-950/80 border-2 border-red-500/30 p-6 md:p-8 rounded-xl shadow-2xl relative backdrop-blur-md text-center max-w-lg mx-auto">
                  <div className="absolute top-0 left-0 w-6 h-6 border-t-2 border-l-2 border-red-500 rounded-tl-lg"></div>
                  <div className="absolute top-0 right-0 w-6 h-6 border-t-2 border-r-2 border-red-500 rounded-tr-lg"></div>
                  <div className="absolute bottom-0 left-0 w-6 h-6 border-b-2 border-l-2 border-red-500 rounded-bl-lg"></div>
                  <div className="absolute bottom-0 right-0 w-6 h-6 border-b-2 border-r-2 border-red-500 rounded-br-lg"></div>

                  <span className="inline-flex items-center gap-1.5 text-[10px] font-mono font-bold text-red-500 bg-red-950/30 px-3 py-1 rounded-full border border-red-900/40 uppercase mb-2">
                    TIME_UP // หมดเวลาการทดสอบความแม่นยำ
                  </span>
                  
                  <h2 className="text-3xl font-black uppercase text-white italic tracking-tight mb-2">บทสรุปความเร็วในการตอบสนอง</h2>
                  <p className="text-xs text-slate-400">
                    ข้อมูลผู้สมัครคนปัจจุบัน: <strong className="text-cyan-400">{activeApplicant.fullname}</strong> ({activeApplicant.inGameName})
                  </p>

                  {/* Score box */}
                  <div className="my-6 p-5 bg-slate-900/60 border border-slate-800 rounded-lg max-w-xs mx-auto">
                    <span className="text-[9px] text-slate-500 font-mono tracking-widest block uppercase">CATCH SCORE ACQUIRED</span>
                    <h3 className="text-6xl font-black text-cyan-400 font-mono tracking-tighter italic my-1">{score}</h3>
                    <span className="text-[10px] text-slate-400 block font-mono">คะแนนดิบสะสมสำเร็จในการหลบหลีก</span>
                  </div>

                  {/* Form Submission Action (AJAX Simulation) */}
                  <div className="space-y-4">
                    <div className="p-3 bg-cyan-950/20 border border-cyan-800/30 rounded-lg text-left text-xs text-cyan-300 leading-relaxed flex items-start gap-2.5 max-w-md mx-auto">
                      <Info className="w-4 h-4 text-cyan-400 shrink-0 mt-0.5" />
                      <div>
                        <strong>ระบบประสาน AJAX / Fetch API:</strong> เมื่อคุณกดปุ่มด้านล่าง เว็บหน้ามินิเกมจะส่งค่าตัวเลขคะแนนกลับผ่านทางระบบ <code className="bg-slate-950 px-1 py-0.5 rounded text-yellow-400">update_score.php</code> เพื่อไปอัปเดตช่องฟิลด์ <code className="bg-slate-950 px-1 py-0.5 text-yellow-400 rounded">game_score</code> บนตาราง MySQL จริง!
                      </div>
                    </div>

                    <div className="flex flex-col sm:flex-row gap-3 justify-center">
                      <button
                        onClick={submitSimulatedScore}
                        className="px-6 py-3.5 bg-emerald-600 hover:bg-emerald-500 text-slate-950 font-black uppercase italic tracking-widest rounded transform -skew-x-12 transition-all shadow-[0_5px_15px_rgba(16,185,129,0.3)] hover:scale-[1.02] cursor-pointer flex-1"
                      >
                        <span className="inline-block transform skew-x-12 font-bold text-xs flex items-center justify-center gap-1.5">
                          <Check className="w-4 h-4" /> บันทึกคะแนนผ่าน AJAX (SAVE)
                        </span>
                      </button>
                      <button
                        onClick={startTracking}
                        className="px-6 py-3.5 border border-slate-700 hover:bg-white/10 text-white font-black uppercase italic tracking-widest rounded transform -skew-x-12 transition-all cursor-pointer flex-1"
                      >
                        <span className="inline-block transform skew-x-12 font-bold text-xs">
                          เริ่มทดสอบรอบใหม่
                        </span>
                      </button>
                    </div>
                  </div>
                </div>
              )}

            </div>

            {/* ================= VIRTUAL MYSQL DATABASE SIMULATOR (Embedded) ================= */}
            <div className="bg-slate-950 border-2 border-slate-900 rounded-xl overflow-hidden shadow-2xl relative">
              <div className="p-5 border-b border-slate-900 bg-slate-950 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                <div className="flex items-center gap-3">
                  <div className="p-2 bg-cyan-950/60 rounded border border-cyan-800">
                    <Database className="w-5 h-5 text-cyan-400 animate-pulse" />
                  </div>
                  <div className="text-left">
                    <h2 className="text-sm font-black uppercase text-white italic tracking-tight">Virtual MySQL Table Monitor (ตารางข้อมูลผู้สมัคร)</h2>
                    <p className="text-[10px] text-slate-400 mt-0.5">จำลองการแสดงผลข้อมูลในตาราง <code className="bg-slate-900 px-1 py-0.5 rounded text-yellow-400 font-mono">rov_applicants</code> บนเซิร์ฟเวอร์ MySQL</p>
                  </div>
                </div>

                <button
                  onClick={handleClearDatabase}
                  className="px-3 py-1.5 border border-red-500/40 hover:bg-red-950/20 text-red-400 hover:text-red-300 rounded text-[10px] font-bold uppercase tracking-wider flex items-center gap-1.5 cursor-pointer transition-all"
                >
                  <Trash2 className="w-3.5 h-3.5" /> ล้างข้อมูล (TRUNCATE TABLE)
                </button>
              </div>

              {/* Data Table */}
              <div className="overflow-x-auto">
                <table className="w-full text-left border-collapse">
                  <thead>
                    <tr className="border-b border-slate-900 text-[9px] font-mono tracking-widest text-slate-500 uppercase bg-slate-950">
                      <th className="p-3 font-bold">id (PK)</th>
                      <th className="p-3 font-bold">student_id</th>
                      <th className="p-3 font-bold">fullname</th>
                      <th className="p-3 font-bold">in_game_name</th>
                      <th className="p-3 font-bold">primary_role</th>
                      <th className="p-3 font-bold text-center">game_score</th>
                      <th className="p-3 font-bold text-center">Tier Rank</th>
                      <th className="p-3 font-bold text-right">created_at</th>
                    </tr>
                  </thead>
                  <tbody className="divide-y divide-slate-900 text-[11px] text-slate-300 font-mono">
                    {applicants.length === 0 ? (
                      <tr>
                        <td colSpan={8} className="p-8 text-center text-slate-500 italic">
                          ยังไม่มีข้อมูลผู้ลงสมัครในฐานข้อมูลจำลองนี้ กรุณาทำการลงทะเบียนผู้สมัครรายใหม่ หรือเข้าสู่ระบบด้านบนเพื่อบันทึกประวัติสะสมสถิติคะแนน!
                        </td>
                      </tr>
                    ) : (
                      [...applicants].sort((a,b) => b.gameScore - a.gameScore).map((row, index) => {
                        const rank = getSimulatedRank(row.gameScore);
                        const isActive = activeApplicant && activeApplicant.id === row.id;
                        return (
                          <tr 
                            key={row.id} 
                            className={`transition-colors duration-500 ${
                              isActive 
                                ? 'bg-cyan-950/20 text-cyan-300 border-l-4 border-cyan-500 font-bold' 
                                : 'hover:bg-slate-900/30'
                            }`}
                          >
                            <td className="p-3 text-slate-500">#{row.id}</td>
                            <td className="p-3 font-semibold text-slate-300">{row.studentId}</td>
                            <td className="p-3 text-neutral-100 font-sans">{row.fullname}</td>
                            <td className="p-3 text-slate-300">{row.inGameName}</td>
                            <td className="p-3 text-slate-400 font-sans text-[10px]">{row.primaryRole}</td>
                            <td className="p-3 text-center text-cyan-400 font-black italic">{row.gameScore} PTS</td>
                            <td className="p-3 text-center">
                              <span className={`px-2 py-0.5 text-[8px] font-bold uppercase rounded border ${rank.color}`}>
                                {rank.name}
                              </span>
                            </td>
                            <td className="p-3 text-right text-[9px] text-slate-500">{row.createdAt}</td>
                          </tr>
                        );
                      })
                    )}
                  </tbody>
                </table>
              </div>

              {/* Informative Stats */}
              <div className="p-3 bg-slate-950 border-t border-slate-900 text-[9px] text-slate-500 font-mono flex flex-col sm:flex-row items-center justify-between gap-2">
                <span>TOTAL RECORDS IN DATABASE: {applicants.length} ROWS</span>
                <span>ENGINE: InnoDB (MySQL 8.0+)</span>
              </div>
            </div>

          </div>

        {/* RIGHT COLUMN: DYNAMIC TELEMETRY LOG PANEL */}
        {true && (
          <div className="lg:col-span-4 w-full space-y-6">
            
            {/* Live Terminal Monitor (Simulated PHP Output Panel) */}
            <div className="bg-slate-950 border-2 border-slate-900 rounded-xl overflow-hidden shadow-2xl">
              <div className="p-3 bg-slate-950 border-b border-slate-900 flex items-center justify-between">
                <div className="flex items-center gap-1.5">
                  <Terminal className="w-4 h-4 text-cyan-400 animate-pulse" />
                  <span className="text-[10px] font-mono font-bold uppercase text-slate-200 tracking-wider">เซิร์ฟเวอร์ PHP Debug Console</span>
                </div>
                <div className="flex items-center gap-1">
                  <span className="h-1.5 w-1.5 rounded-full bg-emerald-500"></span>
                  <span className="text-[8px] font-mono text-slate-500 uppercase">SYS_LOG</span>
                </div>
              </div>

              {/* Console log list */}
              <div className="p-4 bg-[#030307] h-[280px] overflow-y-auto font-mono text-[10px] space-y-2.5 leading-relaxed scrollbar-thin">
                {phpConsole.length === 0 ? (
                  <div className="h-full flex items-center justify-center text-slate-600 text-center italic p-4">
                    ยังไม่มีข้อมูลกิจกรรมเข้าเซิร์ฟเวอร์ กรุณากรอกฟอร์มลงทะเบียนด้านซ้ายเพื่อทดสอบการทำงานของ PDO และส่งคะแนน
                  </div>
                ) : (
                  phpConsole.map((log, index) => {
                    let color = 'text-slate-400';
                    if (log.type === 'success') color = 'text-emerald-400 font-bold';
                    if (log.type === 'sql') color = 'text-amber-400';
                    if (log.type === 'error') color = 'text-red-400 font-bold';
                    if (log.type === 'js') color = 'text-sky-400';

                    return (
                      <div key={index} className="border-b border-slate-950/40 pb-1.5 last:border-0">
                        <div className="flex justify-between items-center text-[8px] text-slate-600 mb-0.5">
                          <span>TIMESTAMP: {log.timestamp}</span>
                          <span>{log.type.toUpperCase()}</span>
                        </div>
                        <p className={`${color} whitespace-pre-wrap`}>{log.text}</p>
                      </div>
                    );
                  })
                )}
              </div>

              {/* Simulated PHP actions */}
              <div className="p-3 bg-slate-950 border-t border-slate-900 flex justify-between items-center text-[9px] font-mono text-slate-400">
                <span>PDO_STATUS: STABLE</span>
                <button 
                  onClick={() => { SoundEffects.playClick(); setPhpConsole([]); }} 
                  className="text-cyan-400 hover:text-cyan-300 font-bold uppercase tracking-wider flex items-center gap-1 cursor-pointer"
                >
                  <Trash2 className="w-3 h-3" /> เคลียร์คอนโซล
                </button>
              </div>
            </div>

            {/* Application Info Panel */}
            <div className="bg-slate-950 border border-slate-900 p-5 rounded-xl space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                <Medal className="w-5 h-5 text-yellow-500 animate-pulse" />
                <h3 className="text-xs font-black uppercase text-slate-200 tracking-wider">เกณฑ์คะแนนและอันดับการสอบ</h3>
              </div>

              <div className="space-y-2">
                <div className="flex justify-between items-center text-xs border-b border-slate-900/60 pb-1">
                  <span className="text-slate-400">0 - 5 PTS:</span>
                  <span className="text-amber-600 font-mono font-bold uppercase">Bronze Tier (ทหารฝึกหัด)</span>
                </div>
                <div className="flex justify-between items-center text-xs border-b border-slate-900/60 pb-1">
                  <span className="text-slate-400">6 - 15 PTS:</span>
                  <span className="text-slate-400 font-mono font-bold uppercase">Silver Tier (ขุนพลแกร่ง)</span>
                </div>
                <div className="flex justify-between items-center text-xs border-b border-slate-900/60 pb-1">
                  <span className="text-slate-400">16 - 25 PTS:</span>
                  <span className="text-yellow-500 font-mono font-bold uppercase">Gold Tier (อัศวินทองคำ)</span>
                </div>
                <div className="flex justify-between items-center text-xs border-b border-slate-900/60 pb-1">
                  <span className="text-slate-400">26 - 35 PTS:</span>
                  <span className="text-emerald-400 font-mono font-bold uppercase">Platinum Tier (ยอดฝีมือ)</span>
                </div>
                <div className="flex justify-between items-center text-xs border-b border-slate-900/60 pb-1">
                  <span className="text-slate-400">36 - 45 PTS:</span>
                  <span className="text-sky-400 font-mono font-bold uppercase">Diamond Tier (โปรเพลเยอร์)</span>
                </div>
                <div className="flex justify-between items-center text-xs">
                  <span className="text-slate-400">46+ PTS:</span>
                  <span className="text-red-500 font-mono font-black uppercase animate-pulse">Glorious Conqueror</span>
                </div>
              </div>
            </div>

            {/* XAMPP Code Copier Panel */}
            <div className="bg-slate-950 border border-slate-900 p-5 rounded-xl space-y-4">
              <div className="flex items-center gap-2 pb-2 border-b border-slate-900">
                <FileCode className="w-5 h-5 text-cyan-400 animate-pulse" />
                <h3 className="text-xs font-black uppercase text-slate-200 tracking-wider">คัดลอกซอร์สโค้ดสำหรับ XAMPP</h3>
              </div>

              <div className="space-y-3">
                <p className="text-[11px] text-slate-400 leading-relaxed">
                  หากคุณดาวน์โหลด ZIP แล้วหน้าเว็บไม่ยอมอัปเดต (เกิดจากเบราว์เซอร์จำค่าแคชของ <code className="text-cyan-300">localhost</code> เดิมไว้) คุณสามารถเลือกไฟล์และคัดลอกซอร์สโค้ดไปวางในเครื่องตรงๆ ได้ทันที:
                </p>

                <div>
                  <label className="block text-[9px] font-bold text-cyan-400 uppercase tracking-widest font-mono mb-1">
                    เลือกไฟล์ที่ต้องการคัดลอก (Select File)
                  </label>
                  <select
                    value={selectedFile.name}
                    onChange={(e) => {
                      const found = sourceFiles.find(f => f.name === e.target.value);
                      if (found) setSelectedFile(found);
                    }}
                    className="w-full px-3 py-2 rounded bg-slate-900 border border-slate-800 text-slate-200 outline-none text-xs cursor-pointer font-mono"
                  >
                    {sourceFiles.map(file => (
                      <option key={file.name} value={file.name}>{file.name}</option>
                    ))}
                  </select>
                </div>

                <div className="p-3 bg-slate-900/60 rounded border border-slate-800/40 space-y-1.5 text-[10px]">
                  <div className="flex justify-between text-[9px] font-mono text-slate-500">
                    <span>รายละเอียดไฟล์:</span>
                    <span className="text-cyan-400 uppercase font-mono">{selectedFile.language}</span>
                  </div>
                  <p className="text-slate-300 font-sans leading-relaxed">{selectedFile.description}</p>
                  
                  <div className="pt-1.5 border-t border-slate-900 text-slate-400 font-mono text-[9px]">
                    <span>บันทึกไปที่:</span>{' '}
                    <code className="text-yellow-400 bg-slate-950 px-1 py-0.5 rounded select-all font-mono">
                      C:/xampp/htdocs/udru_esports/{selectedFile.name}
                    </code>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-2 pt-1">
                  <button
                    onClick={() => handleCopyCode(selectedFile.content)}
                    className="py-2.5 bg-cyan-600 hover:bg-cyan-500 text-slate-950 text-xs font-bold uppercase rounded flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95"
                  >
                    {copiedFile === selectedFile.name ? (
                      <>
                        <Check className="w-3.5 h-3.5" /> คัดลอกแล้ว!
                      </>
                    ) : (
                      <>
                        <Copy className="w-3.5 h-3.5" /> คัดลอกโค้ด
                      </>
                    )}
                  </button>

                  <button
                    onClick={() => handleDownloadFile(selectedFile)}
                    className="py-2.5 border border-slate-800 hover:bg-slate-900 text-slate-300 hover:text-white text-xs font-bold uppercase rounded flex items-center justify-center gap-1.5 cursor-pointer transition-all active:scale-95"
                  >
                    <Download className="w-3.5 h-3.5" /> ดาวน์โหลดเดี่ยว
                  </button>
                </div>
              </div>
            </div>

          </div>
        )}

      </main>

      {/* ================= FOOTER / METADATA ================= */}
      <footer className="w-full max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between text-[10px] md:text-xs text-slate-500 font-mono pt-6 mt-8 border-t border-slate-950 gap-3">
        <p>© 2026 UDRU E-sports Arena • มหาวิทยาลัยราชภัฏอุดรธานี • สงวนลิขสิทธิ์สถาบันการวิจัย</p>
        <div className="flex items-center gap-3">
          <span>PORT: 3000 (DEV)</span>
          <span className="inline-block h-1.5 w-1.5 rounded-full bg-cyan-500 animate-pulse"></span>
          <span>SYSTEM ONLINE</span>
        </div>
      </footer>

    </div>
  );
}
