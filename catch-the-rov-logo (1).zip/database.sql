-- =========================================================
-- สคริปต์สร้างฐานข้อมูล MySQL สำหรับระบบรับสมัครนักกีฬา UDRU E-sports
-- คำแนะนำ: นำโค้ดทั้งหมดนี้ไปรันในแท็บ SQL ของ phpMyAdmin ใน XAMPP
-- =========================================================

-- 1. สร้างฐานข้อมูลใหม่ (หากยังไม่มีอยู่)
CREATE DATABASE IF NOT EXISTS `udru_esports` 
CHARACTER SET utf8mb4 
COLLATE utf8mb4_unicode_ci;

-- 2. เลือกใช้งานฐานข้อมูลนี้
USE `udru_esports`;

-- 3. สร้างตารางเก็บข้อมูลผู้ลงสมัครนักกีฬาและสถิติคะแนนเกมทดสอบปฏิกิริยาตอบสนอง
CREATE TABLE IF NOT EXISTS `rov_applicants` (
    `id` INT AUTO_INCREMENT PRIMARY KEY,                -- ลำดับที่ (Primary Key, เพิ่มขึ้นอัตโนมัติ)
    `student_id` VARCHAR(20) NOT NULL UNIQUE,          -- รหัสนักศึกษา (ห้ามซ้ำซ้อน)
    `fullname` VARCHAR(100) NOT NULL,                  -- ชื่อ-นามสกุลจริง
    `in_game_name` VARCHAR(50) NOT NULL,               -- ชื่อเรียกในเกม (IGN)
    `primary_role` VARCHAR(50) NOT NULL,               -- ตำแหน่ง/เลนหลักที่ถนัดในเกม RoV
    `game_score` INT DEFAULT 0,                        -- คะแนนดิบจากการทดสอบ (ค่าเริ่มต้นเป็น 0)
    `created_at` TIMESTAMP DEFAULT CURRENT_TIMESTAMP    -- วันและเวลาที่ลงชื่อสมัคร
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
